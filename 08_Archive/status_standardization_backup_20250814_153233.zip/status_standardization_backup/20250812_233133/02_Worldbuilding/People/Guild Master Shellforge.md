---
tags:
- aquabyssos
- person
- stub
type: Person
world: Aquabyssos
status: stub
created: '2025-08-12'
updated: '2025-08-13T01:18:37.007903+00:00'
---


# Guild Master Shellforge

*This is a stub file created to resolve broken links. Content needed.*

## Overview

[Content to be added]

## Related Concepts

- [[Master Index|02 Worldbuilding/Lore/Master Index]]

## References

[Add references here]
