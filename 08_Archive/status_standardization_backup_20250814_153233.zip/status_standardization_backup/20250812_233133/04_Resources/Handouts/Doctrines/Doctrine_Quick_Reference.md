---
title: "Player Handout \u2014 Doctrine Quick Reference"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- factions
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.196268+00:00'
world: Both
---


# Doctrine Quick Reference

Travel feels different under each doctrine. Use this as a vibe guide and checklist for your crew.

## Doctrines
- [[Stealth_and_Ambush_Player|Stealth & Ambush]]
- [[Anchor_Fortress_Player|Anchor Fortress]]
- [[Parasite_Swarm_Player|Parasite Swarm]]
- [[Crystal_Artillery_Player|Crystal Artillery]]
- [[Carrier_Strike_Player|Carrier Strike]]
- [[Trade_Escort_Player|Trade Escort]]
- [[Guerrilla_Currents_Player|Guerrilla Currents]]
- [[Zealot_Crusade_Player|Zealot Crusade]]
- [[Memory_Warfare_Player|Memory Warfare]]
- [[Reality_Control_Player|Reality Control]]
- [[Humanitarian_Relief_Player|Humanitarian Relief]]
- [[Pirate_Confederacy_Player|Pirate Confederacy]]

## Cross-References

- [[Aethermoor_Session_01|06 GM Resources/Session Packets/Aethermoor Session 01]]
