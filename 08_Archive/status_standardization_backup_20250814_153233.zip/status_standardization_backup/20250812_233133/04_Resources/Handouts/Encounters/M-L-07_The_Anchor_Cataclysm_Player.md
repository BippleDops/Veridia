---
title: "Player Handout \u2014 M-L-07 The Anchor Cataclysm"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- merger
created: '2025-08-11'
updated: '2025-08-13T01:18:37.204730+00:00'
world: Both
---


# The Anchor Cataclysm

One by one, the world’s steadying songs fall silent.

What you notice
- A hush that feels wrong
- Maps that don’t match the sea

What you can try
- Keep one song alive
- Choose what to save

Possible outcomes
- A world held together by your hands
- A loss you can count
- A new map
