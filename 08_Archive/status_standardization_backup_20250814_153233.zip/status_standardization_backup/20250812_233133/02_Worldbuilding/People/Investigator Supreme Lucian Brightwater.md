---
tags:
- aquabyssos
- person
- stub
type: Person
world: Aquabyssos
status: stub
created: '2025-08-12'
updated: '2025-08-13T01:18:36.994628+00:00'
---

> [!figure] Portrait
![[04_Resources/Assets/Portraits/portrait-npc-investigator-supreme-lucian-brightwater-investigator-supreme-lucian-brightwater.svg]]



# Investigator Supreme Lucian Brightwater

*This is a stub file created to resolve broken links. Content needed.*

## Overview

[Content to be added]

## Related Concepts

- [[Master Index|02 Worldbuilding/Lore/Master Index]]

## References

[Add references here]
