---
title: "Player Handout \u2014 Parasite Swarm Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.194127+00:00'
world: Both
---


# Parasite Swarm

How it feels
- Living gear, boarding tubes, biohazard drills

What changes in travel
- More boarding actions; infections are a risk

Crew tips
- Medics and engineers stay sharp; fire cleanses
- Marines protect vents and intakes

Risks
- The ship may want what the swarm wants

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
