---
title: "Player Handout \u2014 M-001 Physics Denial"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- merger
created: '2025-08-11'
updated: '2025-08-13T01:18:37.200391+00:00'
world: Both
---


# Physics Denial

The ship forgets which way is down. Tools slide toward the wall that thinks it’s a floor.

What you feel
- Your balance lies to you
- The hull groans in a strange direction

What you can try
- Anchor yourselves and the ship’s song
- Move with care

Possible outcomes
- You ride it out
- Something breaks loose
- The world tilts the wrong way
