---
title: "Player Handout \u2014 X-005 Dream Sailing Convoy"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.210814+00:00'
world: Both
---


# Dream Sailing Convoy

Voices weave in the dark. The whole fleet seems to move as one, drawn along a song no chart can show.

What you notice
- Sleepy smiles on tired faces
- A rhythm under the deck

What you can try
- Add your voice to the song
- Keep watch at the edges

Possible outcomes
- The night shortens under your feet
- The song falters
- A dream gets loose
