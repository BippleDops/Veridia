---
title: "Player Handout \u2014 S-201 Eclipse Raid Window"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- sky
created: '2025-08-11'
updated: '2025-08-13T01:18:37.207175+00:00'
world: Both
---


# Eclipse Raid Window

The light goes strange. Shadows lengthen in the wrong direction, and the air feels thin.

What you notice
- A hush across the deck
- Stars faint in daytime

What you can try
- Keep formation tight
- Trust the cadence of the anchor song

Possible outcomes
- You slip through unseen
- Someone missteps in the half-light
- The enemy finds you first

## Cross-References

- [[Aethermoor_Session_01|06 GM Resources/Session Packets/Aethermoor Session 01]]
