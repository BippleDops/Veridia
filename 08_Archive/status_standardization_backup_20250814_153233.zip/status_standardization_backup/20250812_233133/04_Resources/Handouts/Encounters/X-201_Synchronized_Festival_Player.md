---
title: "Player Handout \u2014 X-201 Synchronized Festival"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.206617+00:00'
world: Both
---


# Synchronized Festival Across Worlds

Music and lanterns echo across the gate. Two parades mirror each other, step for step.

What you notice
- Familiar songs with new words
- Children waving from both sides

What you can try
- Keep the route clear
- Share in the moment without losing focus

Possible outcomes
- The celebration lifts everyone
- A scuffle starts at the edge
- A dream from one world spills into the other
