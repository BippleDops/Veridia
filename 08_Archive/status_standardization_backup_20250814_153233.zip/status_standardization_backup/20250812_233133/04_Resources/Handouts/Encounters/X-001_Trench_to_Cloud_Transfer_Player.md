---
title: "Player Handout \u2014 X-001 Trench-to-Cloud Transfer"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.210288+00:00'
world: Both
---


# Trench-to-Cloud Transfer

Water peels away as sky rushes in. Your sub grows light and quick as the storm takes it by the wings.

What you notice
- Ballast singing
- Wind where there was pressure

What you can try
- Hold steady while systems switch
- Watch the gauges
- Brace for a jolt

Possible outcomes
- A clean leap into the sky
- A rough jolt and a wide turn
- A spin that needs quick hands
