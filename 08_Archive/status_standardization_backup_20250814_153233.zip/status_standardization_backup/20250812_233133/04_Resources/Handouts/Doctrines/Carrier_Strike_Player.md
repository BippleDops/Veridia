---
title: "Player Handout \u2014 Carrier Strike Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.195211+00:00'
world: Both
---


# Carrier Strike

How it feels
- Launch calls, timed cycles, fighters weaving

What changes in travel
- Escorts and screens; altitude/depth bands matter

Crew tips
- Follow the cycle; protect the deck

Risks
- A broken cycle costs lives and time

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
