VAULT IMPROVEMENT PHASE 5: Name & Alias Canonicalizer

Files scanned: 5700
Files updated (alias normalization): 11
Canonical names recorded: 5652
