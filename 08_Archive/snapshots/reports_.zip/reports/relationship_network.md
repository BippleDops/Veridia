# NPC Relationship Network

Generated: 2025-08-13 07:50:56

## Highly Connected NPCs

### Senator (9 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/People/Parliament Loyalists]]
- [[02_Worldbuilding/People/Emperor Thalassius the Wise]]
- [[02_Worldbuilding/People/Banker Titus Goldcurrent]]
- [[02_Worldbuilding/People/Ambassador Nerida Deepcurrent]]
- [[02_Worldbuilding/People/Shadow Parliament]]
- [[02_Worldbuilding/People/The Coral Throne Syndicate]]
- [[02_Worldbuilding/People/Senator Glaucus]]
- [[02_Worldbuilding/People/Prince Caspian Duskwater]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Surface Ambassador Lord Seaworthy]]

### Knight (8 connections)

- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[vault_backup_20250813_073007/02_Worldbuilding/Lore/Crystal Guard]]
- [[02_Worldbuilding/People/High Priestess Celeste Dawnbringer]]
- [[02_Worldbuilding/People/Captain Lyanna Brightshield]]
- [[02_Worldbuilding/People/Shadow Parliament]]
- [[02_Worldbuilding/People/The Biomancers]]
- [[02_Worldbuilding/People/Prince Caspian Duskwater]]
- [[02_Worldbuilding/People/Ambassador Korvin Blacktide]]

### Oracle (8 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Waking Prophets]]
- [[02_Worldbuilding/People/Emperor Thalassius the Wise]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Leviathan Prophets]]
- [[02_Worldbuilding/People/High Priestess Scylla Deepdream]]
- [[02_Worldbuilding/People/Shadow Parliament]]
- [[02_Worldbuilding/People/The Biomancers]]
- [[02_Worldbuilding/People/Prince Caspian Duskwater]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Party]]

### The Sorrowmaster (8 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Parasite Priests]]
- [[02_Worldbuilding/People/Shadow Parliament]]
- [[02_Worldbuilding/People/The Biomancers]]
- [[02_Worldbuilding/People/High Priestess Scylla Deepdream]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Waking Prophets]]
- [[02_Worldbuilding/People/Emperor Thalassius the Wise]]
- [[02_Worldbuilding/People/Prince Caspian Duskwater]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Memory Merchant Valeria Siltweave]]

### Ambassador Nerida Deepcurrent (5 connections)

- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/People/Prince Caspian Duskwater]]
- [[02_Worldbuilding/People/Captain Thaddeus Blackwater]]
- [[02_Worldbuilding/People/Vex Shadowthorn]]
- [[02_Worldbuilding/People/Master Artificer Korvin Gearwright]]

### Sir Marcus Dawnforge (5 connections)

- [[02_Worldbuilding/People/Lord Commander Gareth Steelborn]]
- [[02_Worldbuilding/People/The Crimson Sage]]
- [[02_Worldbuilding/People/Captain Lyanna Brightshield]]
- [[02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/Korvin Blacktide]]

### Scholar Vivienne the Chronicler (5 connections)

- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Keeper of the Shattered Crown Marcus]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Zephyr Goldwhisper]]
- [[vault_backup_20250813_073007/02_Worldbuilding/Groups/Cults_and_Movements/The Crystal Cult]]

### Marcus Shardbreaker Grimm (5 connections)

- [[02_Worldbuilding/People/Lord Commander Gareth Steelborn]]
- [[02_Worldbuilding/People/Captain Lyanna Brightshield]]
- [[02_Worldbuilding/People/Vex Shadowthorn]]
- [[02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/Master Artificer Korvin Gearwright]]

### Lighthouse Keeper (5 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/Lore/Crystal Guard]]
- [[02_Worldbuilding/People/Admiral Cassandra Stormwind]]
- [[02_Worldbuilding/People/Archdruid Thornweaver]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Pressure Pirates]]
- [[02_Worldbuilding/People/Ambassador Korvin Blacktide]]

### The Bloodline Carrier (5 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/People/Order of the Shattered Crown]]
- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/Groups/The Convergence Seekers]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Keeper of the Shattered Crown Marcus]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Professor Aldric Crystalweaver]]

### Sorrow-Root Nightbloom (5 connections)

- [[02_Worldbuilding/People/Archdruid Thornweaver]]
- [[02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/People/Ambassador Korvin Blacktide]]
- [[02_Worldbuilding/People/Zephyr Goldwhisper]]

### His Own Shadow (4 connections)

- [[02_Worldbuilding/People/Shadow Parliament]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/The Waking Prophets]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Memory Merchant Valeria Siltweave]]
- [[02_Worldbuilding/People/The Biomancers]]

### Sister Morwyn Veilkeeper (4 connections)

- [[02_Worldbuilding/People/The Crimson Sage]]
- [[02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/Vex Shadowthorn]]
- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]

### Castellan Ironledger III (4 connections)

- [[02_Worldbuilding/People/Vex Shadowthorn]]
- [[02_Worldbuilding/People/Captain Thaddeus Blackwater]]
- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/People/Master Artificer Korvin Gearwright]]

### The Barnacle (4 connections)

- [[02_Worldbuilding/People/The Biomancers]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Surface Syndicate]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Professor Aldric Crystalweaver]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Memory Harvester Kythara]]

### Keeper of the Shattered Crown Marcus (4 connections)

- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/The Crimson Sage]]
- [[02_Worldbuilding/People/Order of the Shattered Crown]]

### Keeper of the Shattered Crown, Marcus Crystalvein (4 connections)

- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/High Inquisitor Maltheos]]
- [[02_Worldbuilding/People/The Crimson Sage]]
- [[vault_backup_20250813_073007/02_Worldbuilding/People/Order of the Shattered Crown]]

### Empress Tethys the Ever-Drowning (3 connections)

- [[02_Worldbuilding/People/Ambassador Korvin Blacktide]]
- [[02_Worldbuilding/People/Queen Seraphina Lumengarde]]
- [[02_Worldbuilding/People/The Crimson Sage]]

### Senator Marius (3 connections)

- [[vault_backup_20250813_073007/02_Worldbuilding/People/Senator Cordelia Deepcurrent]]
- [[02_Worldbuilding/People/Emperor Thalassius the Wise]]
- [[02_Worldbuilding/People/The Pearl Guard]]

### High Priestess Scylla Deepdream (3 connections)

- [[02_Worldbuilding/People/Ambassador Nerida Deepcurrent]]
- [[02_Worldbuilding/People/The Crimson Sage]]
- [[02_Worldbuilding/People/Sister Morwyn Veilkeeper]]

