---
title: "Player Handout \u2014 Humanitarian Relief Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.192877+00:00'
world: Both
---


# Humanitarian Relief

How it feels
- Triage tables, open doors, long days

What changes in travel
- More rescues; faster routes for convoys; less loot

Crew tips
- Keep morale and medicine up; celebrate small wins

Risks
- You can’t save everyone; choose and carry it well

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
