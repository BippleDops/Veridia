---
title: "Player Handout \u2014 D-L-03 Deep Mother Dream Tide"
type: handout
status: complete
audience: player
tags:
- both
- complete
- depth
- encounter
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.207712+00:00'
world: Both
---


# Deep Mother Dream Tide

Sleep tugs at the bones. The ship hums a lullaby no one taught it.

What you notice
- Eyes grow heavy together
- Dreams feel like places you could walk

What you can try
- Hold hands and hold on
- Listen for meaning

Possible outcomes
- A shared omen to carry forward
- A dream that won’t let go
- A memory you didn’t mean to lose

## Cross-References

- [[Aquabyssos_Session_01|06 GM Resources/Session Packets/Aquabyssos Session 01]]
