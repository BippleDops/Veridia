---
title: "Player Handout \u2014 Merger Vessels"
type: handout
status: complete
audience: player
tags:
- both
- complete
- handout
- merger
- vehicles
created: '2025-08-11'
updated: '2025-08-13T01:18:37.192342+00:00'
world: Both
---


# Merger Vessels — What Impossible Looks Like

- Time Skipper: Deck clocks run backwards; wake arrives before hull.
- Dream Barge: Velvet shadows pool; lullabies steer better than wheels.
- Probability Sloop: Dice altars on the bridge; odds etched into rails.
- Paradox Dreadnought: Staircases that disagree; cannons that un-fire.
- Möbius Ferry: Corridor returns you to yourself; cargo that is you.

These ships demand anchors, charts, and strong minds. Read [[Merger Hybrid Vehicles]] and [[Aquabyssos|02 Worldbuilding/Quests/Aquabyssos]].

## Cross-References

- [[07_Player_Resources/Player_Portal|07 Player Resources/Player Portal]]
