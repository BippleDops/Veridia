---
title: "Player Handout \u2014 D-L-11 The Last Anchor"
type: handout
status: complete
audience: player
tags:
- both
- complete
- depth
- encounter
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.202311+00:00'
world: Both
---


# The Last Anchor

Only one song still holds the world together, and you can feel it in your teeth.

What you notice
- A single note in the air
- The horizon looks thin

What you can try
- Keep the song steady
- Do what it takes

Possible outcomes
- The world steadies under your hands
- It holds for now
- It breaks

## Cross-References

- [[Aquabyssos_Session_01|06 GM Resources/Session Packets/Aquabyssos Session 01]]
