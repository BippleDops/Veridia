---
tags:
- complete
- factions
- groups
- lore
- master-index
- navigation
- universal
status: complete
world: Universal
type: Lore
created_by: Agent-20
created: '2025-08-11'
last_updated: 2025-08-11
completion: 100%
total_organizations: 46
updated: '2025-08-13T01:18:31.091080+00:00'
---



# Master Groups Index
*Comprehensive Directory of All Factions and Organizations*

## Index Overview

This comprehensive index organizes all 46 completed organizations and factions across both campaign worlds, categorized by type, influence level, alignment, and campaign relevance. Each entry includes power structures, relationships, conflicts, and adventure opportunities.

## Quick Navigation
- [[#Government & Official Organizations]] - State institutions and official bodies
- [[#Military & Security Forces]] - Armed forces and law enforcement organizations
- [[#Religious & Spiritual Organizations]] - Churches, cults, and spiritual groups
- [[#Commercial & Economic Powers]] - Trade guilds, merchant organizations, economic forces
- [[#Criminal & Underground Networks]] - Illegal organizations and shadow networks
- [[#Academic & Scholarly Institutions]] - Research organizations and educational bodies
- [[#Cultural & Professional Groups]] - Guilds, societies, and professional organizations
- [[#Mysterious & Ancient Orders]] - Secret societies and ancient organizations
- [[#Cross-Campaign Organizations]] - Groups operating in both worlds
- [[#Power Level Analysis]] - Organizations by influence and threat level
- [[#Relationship Network Maps]] - Faction interactions and alliances

---

## Government & Official Organizations

### Primary Governmental Bodies

#### **[[Parliament of Echoes]]** - The Aquabyssos Government
- **World**: Aquabyssos
- **Type**: Legislative Government Body
- **Alignment**: Lawful Neutral (Corrupted)
- **Size**: 200+ members across both chambers
- **Headquarters**: [[Parliament of Echoes]] complex, [[Abyssos Prime]]
- **Leadership**: Senator Glaucus (Public), Shadow Chamber (Secret)
- **Power Level**: Very High (National governance)
- **Key Functions**: Law creation, governmental oversight, imperial balance
- **Major Conflicts**: Shadow corruption, imperial tension, transparency demands
- **Secrets**: Shadow Chamber operations, memory manipulation, corruption networks
- **Campaign Role**: Political intrigue center, corruption investigation target
- **Adventure Levels**: 8-20
- **Allied Organizations**: Silverscale Consortium, Shadow Conspiracy
- **Opposed Organizations**: Crystal Wardens, Reform movements

#### **[[The Crown Authority]]** - The Aethermoor Government
- **World**: Aethermoor
- **Type**: Royal Government System
- **Alignment**: Lawful Good (Compromised)
- **Size**: 500+ officials and administrators
- **Headquarters**: [[Royal Palace of Meridian]], [[Crystalhaven]]
- **Leadership**: Queen Seraphina Lumengarde
- **Power Level**: Very High (National governance)
- **Key Functions**: Royal administration, law enforcement, national defense
- **Major Conflicts**: Queen's corruption, succession questions, regional tensions
- **Secrets**: Queen's crystal corruption, hidden succession plans
- **Campaign Role**: Royal patron, governmental authority, quest source
- **Adventure Levels**: 3-18
- **Allied Organizations**: Crystal Wardens, Merchant Princes
- **Opposed Organizations**: Purist Coalition, Exile movement

### Regional Governance Bodies

#### **[[The Crystal Throne]]** - Royal Authority Symbol
- **World**: Aethermoor
- **Type**: Royal Institution/Authority
- **Alignment**: Lawful Neutral
- **Size**: Royal household and court (200+ members)
- **Headquarters**: [[Crystalhaven]], [[The Crystal Throne]] chamber
- **Leadership**: Queen Seraphina Lumengarde
- **Power Level**: Very High (Royal authority)
- **Key Functions**: Royal ceremonies, governmental legitimacy, power focus
- **Major Conflicts**: Legitimacy questions, corruption concealment, power distribution
- **Symbolic Importance**: Royal authority, governmental legitimacy, cultural unity
- **Campaign Role**: Royal court center, legitimacy questions, power struggles
- **Adventure Levels**: 8-18
- **Connected Organizations**: The Crown Authority, Crystal Wardens
- **Opposing Forces**: Exile claimants, Reform movements

#### **[[Goldspire Confederacy]]** - Independent City-State
- **World**: Aethermoor
- **Type**: Independent City Government
- **Alignment**: Lawful Neutral
- **Size**: City population (62,000) with governing council
- **Headquarters**: [[Goldspire Port]], confederacy buildings
- **Leadership**: Merchant Council confederation
- **Power Level**: Moderate (Regional independence)
- **Key Functions**: Independent governance, neutral trade, diplomatic balance
- **Major Conflicts**: Independence maintenance, trade competition, diplomatic pressure
- **Unique Features**: Neutral territory, independent taxation, diplomatic immunity
- **Campaign Role**: Neutral meeting ground, independent authority, diplomatic missions
- **Adventure Levels**: 2-12
- **Allied Organizations**: Independent merchants, Neutral trading partners
- **Diplomatic Relations**: Careful neutrality with all major powers

---

## Military & Security Forces

### National Military Organizations

#### **[[Crystal Wardens]]** - Elite Royal Guard
- **World**: Aethermoor
- **Type**: Elite Military/Security Organization
- **Alignment**: Lawful Good
- **Size**: 500+ elite warriors and support staff
- **Headquarters**: [[Azure Citadel]], [[Crystalhaven]]
- **Leadership**: Lord Commander Gareth Steelborn
- **Power Level**: High (Elite military force)
- **Key Functions**: Royal protection, crystal corruption prevention, elite operations
- **Major Conflicts**: Crystal corruption threats, resource limitations, political pressure
- **Military Specialization**: Crystal magic integration, elite combat, corruption resistance
- **Campaign Role**: Military allies, quest patrons, elite opposition
- **Adventure Levels**: 6-18
- **Allied Organizations**: The Crown Authority, Temple hierarchies
- **Opposed Organizations**: Shadow networks, Criminal organizations

#### **[[The Deepwatch Guard]]** - Deep Territory Security
- **World**: Aquabyssos
- **Type**: Specialized Military/Security Force
- **Alignment**: Lawful Neutral
- **Size**: 800+ specialized personnel
- **Headquarters**: Deep territory installations, [[Abyssos Prime]]
- **Leadership**: Admiral Thorne Blackwater (naval integration)
- **Power Level**: High (Deep territory control)
- **Key Functions**: Deep territory security, extreme environment operations, threat response
- **Major Conflicts**: Extreme environment challenges, deep territory threats, resource demands
- **Military Specialization**: Deep pressure operations, extreme environment combat, deep exploration
- **Campaign Role**: Deep exploration allies, extreme environment guides, security partners
- **Adventure Levels**: 10-20
- **Allied Organizations**: Imperial government, Deep territory settlements
- **Operational Challenges**: Extreme environment, Communication difficulties, Supply logistics

### Specialized Security Organizations

#### **[[Consortium Security Constructs]]** - Corporate Security
- **World**: Aquabyssos
- **Type**: Corporate Security/Military Force
- **Alignment**: Lawful Neutral
- **Size**: 300+ security personnel plus constructs
- **Headquarters**: [[Silverscale Banking House]], corporate facilities
- **Leadership**: Director Hadrian Silverscale
- **Power Level**: Moderate-High (Corporate authority)
- **Key Functions**: Corporate protection, financial security, construct operations
- **Major Conflicts**: Corporate interests vs. public good, legal boundaries, construct ethics
- **Security Specialization**: Financial crime prevention, corporate espionage, construct integration
- **Campaign Role**: Corporate security, investigation obstacles, neutral security provider
- **Adventure Levels**: 4-14
- **Allied Organizations**: Silverscale Consortium, Corporate interests
- **Legal Status**: Private security with governmental contracts

#### **[[Purist Coalition Thugs]]** - Extremist Enforcement
- **World**: Aethermoor
- **Type**: Extremist Paramilitary Organization
- **Alignment**: Lawful Evil
- **Size**: 200+ active militants
- **Headquarters**: Distributed across anti-crystal territories
- **Leadership**: High Inquisitor Maltheos
- **Power Level**: Moderate (Regional threat)
- **Key Functions**: Crystal corruption elimination, extremist enforcement, fear tactics
- **Major Conflicts**: Crystal users, governmental authority, moderate factions
- **Extremist Methods**: Violence against corrupted, intimidation tactics, property destruction
- **Campaign Role**: Antagonist force, moral challenges, extremist opposition
- **Adventure Levels**: 3-15
- **Allied Organizations**: Purist Coalition, Anti-crystal extremists
- **Opposed Organizations**: Crystal Wardens, Crown Authority, Medical communities

---

## Religious & Spiritual Organizations

### Major Religious Institutions

#### **[[Temple of Divine Order]]** - State Religion Authority
- **World**: Aethermoor
- **Type**: Official Religious Institution
- **Alignment**: Lawful Good
- **Size**: 1000+ clergy and religious staff
- **Headquarters**: [[Cathedral of Light]], [[Crystalhaven]]
- **Leadership**: High Priestess Celeste Dawnbringer
- **Power Level**: High (Religious authority)
- **Key Functions**: Spiritual guidance, healing services, governmental blessing
- **Major Conflicts**: Political involvement, doctrinal interpretation, corruption response
- **Religious Focus**: Divine healing, light magic, community service
- **Campaign Role**: Religious patron, healing services, moral guidance
- **Adventure Levels**: 1-16
- **Allied Organizations**: The Crown Authority, Medical communities
- **Religious Tensions**: Balance between political support and spiritual independence

#### **[[Order of the Drowned Star]]** - Mystery Religion
- **World**: Aquabyssos
- **Type**: Mystical Religious Order
- **Alignment**: Chaotic Neutral
- **Size**: 150+ initiated members
- **Headquarters**: Hidden temples, mystical sites
- **Leadership**: Elder council of initiated masters
- **Power Level**: Moderate (Mystical influence)
- **Key Functions**: Mystical knowledge preservation, reality research, cosmic understanding
- **Major Conflicts**: Government suspicion, orthodox religion, dangerous knowledge
- **Religious Focus**: Cosmic mysteries, reality manipulation, forbidden knowledge
- **Campaign Role**: Mystical allies, dangerous knowledge source, reality guides
- **Adventure Levels**: 8-18
- **Allied Organizations**: Academic researchers, Reality specialists
- **Religious Dangers**: Cosmic horror exposure, Reality instability, Madness risks

### Cult and Extremist Organizations

#### **[[The Leviathan Cult]]** - Ancient Entity Worship
- **World**: Aquabyssos
- **Type**: Extremist Religious Cult
- **Alignment**: Chaotic Evil
- **Size**: 80+ active cultists
- **Headquarters**: Deep territory hidden temples
- **Leadership**: High Cultist network
- **Power Level**: Moderate (Hidden threat)
- **Key Functions**: Ancient entity worship, sacrifice rituals, deep exploration
- **Major Conflicts**: Government authority, orthodox religion, public safety
- **Cult Activities**: Ancient entity summoning, Sacrifice rituals, Deep territory operations
- **Campaign Role**: Cult antagonists, Horror encounters, Ancient entity connections
- **Adventure Levels**: 10-20
- **Opposed Organizations**: Religious authorities, Government security, Public safety
- **Cult Dangers**: Ancient entity summoning, Human sacrifice, Deep territory threats

#### **[[Cult of Screams]]** - Sound-Based Religious Extremists
- **World**: Aquabyssos
- **Type**: Extremist Sound Cult
- **Alignment**: Chaotic Evil
- **Size**: 60+ active cultists
- **Headquarters**: [[Screaming Gardens]], hidden sound temples
- **Leadership**: Scream Master hierarchy
- **Power Level**: Moderate (Localized threat)
- **Key Functions**: Sound magic worship, acoustic terrorism, fear cultivation
- **Major Conflicts**: Public safety, Noise ordinances, Mental health concerns
- **Cult Methods**: Sonic attacks, Fear cultivation, Acoustic manipulation
- **Campaign Role**: Sound-based antagonists, Fear encounters, Acoustic challenges
- **Adventure Levels**: 6-16
- **Opposed Organizations**: Public safety, Mental health advocates, Community groups
- **Cult Threats**: Sonic damage, Fear effects, Acoustic terrorism

### Spiritual and Mystical Orders

#### **[[The Order of the Azure Flame]]** - Mystical Fire Order
- **World**: Aethermoor
- **Type**: Mystical Religious Order
- **Alignment**: Lawful Good
- **Size**: 120+ initiated members
- **Headquarters**: Mountain monasteries, flame temples
- **Leadership**: Flame Master council
- **Power Level**: Moderate (Mystical authority)
- **Key Functions**: Fire magic mastery, spiritual discipline, mystical training
- **Major Conflicts**: Political demands, Resource limitations, Mystical dangers
- **Mystical Focus**: Fire magic mastery, Spiritual discipline, Elemental balance
- **Campaign Role**: Mystical training, Fire magic allies, Spiritual guidance
- **Adventure Levels**: 4-14
- **Allied Organizations**: Mystical communities, Elemental specialists
- **Training Services**: Fire magic instruction, Spiritual discipline, Mystical development

---

## Commercial & Economic Powers

### Major Trading Organizations

#### **[[Merchant Princes]]** - Commercial Ruling Elite
- **World**: Aethermoor
- **Type**: Commercial Oligarchy/Government
- **Alignment**: Lawful Neutral
- **Size**: 5 core princes plus 200+ associated merchants
- **Headquarters**: [[Port Meridian]], merchant districts
- **Leadership**: Lord Aurelius Goldwave (Head of Council)
- **Power Level**: Very High (Economic control)
- **Key Functions**: Economic governance, Trade regulation, Commercial policy
- **Major Conflicts**: Government authority, Trade competition, Economic regulation
- **Economic Control**: International trade, Commercial law, Market regulation
- **Campaign Role**: Economic patrons, Trade mission providers, Political allies
- **Adventure Levels**: 2-16
- **Allied Organizations**: The Crown Authority, International traders
- **Economic Tensions**: Balance between profit and public good

#### **[[Silverscale Consortium]]** - Financial Empire
- **World**: Aquabyssos
- **Type**: Banking and Financial Corporation
- **Alignment**: Lawful Evil (Corrupt)
- **Size**: 400+ employees and agents
- **Headquarters**: [[Silverscale Banking House]], [[Abyssos Prime]]
- **Leadership**: Director Hadrian Silverscale
- **Power Level**: Very High (Financial control)
- **Key Functions**: Banking services, Investment management, Financial manipulation
- **Major Conflicts**: Government regulation, Corruption investigation, Competition
- **Financial Control**: Banking monopoly, Investment networks, Corruption funding
- **Secrets**: Money laundering, Corruption financing, Political manipulation
- **Campaign Role**: Financial services, Corruption investigation target, Economic antagonist
- **Adventure Levels**: 6-18
- **Allied Organizations**: Parliament of Echoes (corrupted), Criminal networks
- **Criminal Activities**: Money laundering, Political corruption, Economic manipulation

### Specialized Trading Groups

#### **[[The Deepwater Trading Consortium]]** - Maritime Commerce
- **World**: Aquabyssos
- **Type**: Maritime Trading Organization
- **Alignment**: Lawful Neutral
- **Size**: 200+ traders and maritime specialists
- **Headquarters**: Deep water port facilities
- **Leadership**: Maritime trading council
- **Power Level**: High (Maritime trade control)
- **Key Functions**: Deep water trade, Maritime logistics, International commerce
- **Major Conflicts**: Piracy threats, Trade competition, Regulatory compliance
- **Maritime Specialization**: Deep water navigation, International shipping, Hazardous cargo
- **Campaign Role**: Maritime adventures, International connections, Trade missions
- **Adventure Levels**: 4-16
- **Allied Organizations**: Maritime communities, International traders
- **Maritime Challenges**: Deep sea dangers, Piracy threats, Navigation hazards

#### **[[Independent Smugglers]]** - Underground Commerce
- **World**: Both
- **Type**: Criminal Trading Network
- **Alignment**: Chaotic Neutral
- **Size**: 150+ active smugglers
- **Headquarters**: Distributed hideouts and safe houses
- **Leadership**: Decentralized leadership structure
- **Power Level**: Moderate (Underground influence)
- **Key Functions**: Illegal goods transportation, Regulatory avoidance, Market access
- **Major Conflicts**: Law enforcement, Trade regulations, Territory disputes
- **Smuggling Specialization**: Contraband transportation, Border crossing, Market infiltration
- **Campaign Role**: Transportation services, Underground contacts, Moral complexity
- **Adventure Levels**: 3-14
- **Allied Organizations**: Criminal networks, Underground economy
- **Legal Status**: Illegal operations with occasional governmental tolerance

### Professional and Craft Organizations

#### **[[Master Artificers Guild]]** - Magical Crafting Authority
- **World**: Aethermoor
- **Type**: Professional Craft Guild
- **Alignment**: Lawful Good
- **Size**: 80+ master artificers plus apprentices
- **Headquarters**: Guild facilities, [[Crystalhaven]]
- **Leadership**: Master Artificer Korvin Gearwright
- **Power Level**: High (Technological control)
- **Key Functions**: Magical item creation, Technological development, Quality standards
- **Major Conflicts**: Resource access, Technological advancement, Ethical boundaries
- **Crafting Specialization**: Magical devices, Crystal integration, Technological innovation
- **Campaign Role**: Equipment providers, Technological allies, Innovation patrons
- **Adventure Levels**: 4-16
- **Allied Organizations**: The Crown Authority, Academic institutions
- **Guild Services**: Custom crafting, Technological consulting, Apprenticeship programs

#### **[[The Artisans' Collective of Master Crafters]]** - General Crafting Guild
- **World**: Both
- **Type**: Multi-Discipline Craft Organization
- **Alignment**: Lawful Neutral
- **Size**: 300+ artisans across all crafts
- **Headquarters**: Craft districts in major cities
- **Leadership**: Elected council of craft masters
- **Power Level**: Moderate (Economic influence)
- **Key Functions**: Craft standards, Quality control, Market protection
- **Major Conflicts**: Mass production, Quality standards, Economic pressure
- **Craft Specialization**: Multiple craft disciplines, Quality assurance, Traditional methods
- **Campaign Role**: Equipment providers, Craft training, Cultural preservation
- **Adventure Levels**: 1-12
- **Allied Organizations**: Local communities, Traditional culture advocates
- **Guild Values**: Craftsmanship quality, Traditional methods, Community service

---

## Criminal & Underground Networks

### Major Criminal Organizations

#### **[[The Shadow Trade Network]]** - Comprehensive Criminal Empire
- **World**: Aquabyssos
- **Type**: Organized Crime Syndicate
- **Alignment**: Neutral Evil
- **Size**: 400+ active members plus affiliates
- **Headquarters**: [[The Umbral Exchange]], shadow facilities
- **Leadership**: The Shadow Merchant Prime (unknown identity)
- **Power Level**: Very High (Criminal authority)
- **Key Functions**: Illegal commerce, Shadow magic services, Contraband trade
- **Major Conflicts**: Law enforcement, Territory disputes, Competition elimination
- **Criminal Specialization**: Shadow magic applications, Illegal commerce, Corruption networks
- **Campaign Role**: Criminal services, Underground contacts, Moral challenges
- **Adventure Levels**: 8-20
- **Allied Organizations**: Shadow Conspiracy, Corrupt officials
- **Criminal Services**: Contraband trade, Information brokerage, Illegal services

#### **[[The Whisper Syndicate]]** - Information and Influence Network
- **World**: Both
- **Type**: Information Crime Organization
- **Alignment**: Neutral Evil
- **Size**: 250+ agents and informants
- **Headquarters**: Distributed network, hidden facilities
- **Leadership**: Syndicate council (identities unknown)
- **Power Level**: High (Information control)
- **Key Functions**: Information brokerage, Blackmail operations, Influence peddling
- **Major Conflicts**: Information security, Competition, Law enforcement
- **Criminal Specialization**: Information gathering, Blackmail operations, Political manipulation
- **Campaign Role**: Information sources, Investigation complications, Political intrigue
- **Adventure Levels**: 6-18
- **Allied Organizations**: Corrupt officials, Criminal networks
- **Information Services**: Intelligence gathering, Political information, Personal secrets

### Specialized Criminal Groups

#### **[[Shadow Surgeons Collective]]** - Medical Horror Organization
- **World**: Aquabyssos
- **Type**: Criminal Medical Organization
- **Alignment**: Chaotic Evil
- **Size**: 100+ surgeons and support staff
- **Headquarters**: [[Reflection Pools - Surgical Theater]], hidden facilities
- **Leadership**: Vex Shadowthorn (The Silhouette Surgeon Prime)
- **Power Level**: Very High (Reality manipulation)
- **Key Functions**: Shadow separation surgery, Consciousness alteration, Reality manipulation
- **Major Conflicts**: Medical ethics, Law enforcement, Public safety
- **Criminal Specialization**: Shadow surgery, Memory manipulation, Consciousness control
- **Horror Elements**: Medical experimentation, Consciousness separation, Reality alteration
- **Campaign Role**: Horror antagonists, Medical mysteries, Reality threats
- **Adventure Levels**: 12-20
- **Opposed Organizations**: Medical communities, Law enforcement, Reality protection
- **Criminal Methods**: Shadow surgery, Memory alteration, Consciousness experimentation

#### **[[The Brotherhood of the Black Anchor]]** - Maritime Crime
- **World**: Both
- **Type**: Maritime Criminal Organization
- **Alignment**: Chaotic Evil
- **Size**: 180+ pirates and maritime criminals
- **Headquarters**: Hidden maritime bases, pirate harbors
- **Leadership**: Captain council (rotating leadership)
- **Power Level**: High (Maritime threat)
- **Key Functions**: Maritime piracy, Smuggling operations, Harbor control
- **Major Conflicts**: Naval forces, Merchant shipping, Harbor security
- **Criminal Specialization**: Maritime piracy, Shipping disruption, Harbor infiltration
- **Campaign Role**: Maritime antagonists, Piracy threats, Adventure complications
- **Adventure Levels**: 4-16
- **Allied Organizations**: Other criminal networks, Corrupt harbors
- **Maritime Crimes**: Ship piracy, Cargo theft, Harbor extortion

### Underground Service Organizations

#### **[[Shadowhaven Merchant Marine]]** - Criminal Transportation
- **World**: Aquabyssos
- **Type**: Criminal Transportation Network
- **Alignment**: Chaotic Neutral
- **Size**: 120+ transportation specialists
- **Headquarters**: Hidden ports, mobile fleet
- **Leadership**: Fleet captain council
- **Power Level**: Moderate (Transportation control)
- **Key Functions**: Illegal transportation, Smuggling support, Escape services
- **Major Conflicts**: Maritime law, Port security, Competition
- **Transportation Specialization**: Illegal passenger transport, Contraband shipping, Escape routes
- **Campaign Role**: Transportation services, Escape assistance, Underground travel
- **Adventure Levels**: 3-13
- **Allied Organizations**: Smuggling networks, Criminal organizations
- **Transportation Services**: Illegal passenger transport, Contraband shipping, Emergency evacuation

---

## Academic & Scholarly Institutions

### Research and Educational Organizations

#### **[[The Seekers' Guild]]** - Knowledge Research Organization
- **World**: Both
- **Type**: Academic Research Guild
- **Alignment**: Lawful Neutral
- **Size**: 150+ researchers and scholars
- **Headquarters**: Research facilities, libraries
- **Leadership**: Council of senior researchers
- **Power Level**: Moderate (Knowledge influence)
- **Key Functions**: Knowledge research, Information preservation, Academic advancement
- **Major Conflicts**: Funding limitations, Political pressure, Dangerous knowledge
- **Research Specialization**: Cross-disciplinary research, Ancient knowledge, Mystical phenomena
- **Campaign Role**: Research patrons, Knowledge sources, Academic allies
- **Adventure Levels**: 3-16
- **Allied Organizations**: Academic institutions, Government research
- **Research Focus**: Historical mysteries, Mystical phenomena, Technological advancement

#### **[[The Convergence Seekers]]** - Reality Research Organization
- **World**: Both
- **Type**: Specialized Reality Research Group
- **Alignment**: True Neutral
- **Size**: 60+ reality researchers
- **Headquarters**: Hidden research facilities
- **Leadership**: Research council of reality specialists
- **Power Level**: High (Reality knowledge)
- **Key Functions**: Reality research, Dimensional study, Convergence preparation
- **Major Conflicts**: Reality stability, Governmental concern, Dangerous research
- **Research Specialization**: Reality manipulation, Dimensional theory, World convergence
- **Research Dangers**: Reality instability, Dimensional tears, Consciousness damage
- **Campaign Role**: Reality guides, Convergence experts, Dimensional advisors
- **Adventure Levels**: 10-20
- **Allied Organizations**: Mystical communities, Academic researchers
- **Research Goals**: World convergence understanding, Reality stabilization, Dimensional navigation

### Knowledge Preservation Organizations

#### **[[Investigators Anonymous]]** - Investigation Training Organization
- **World**: Universal
- **Type**: Professional Training Guild
- **Alignment**: Lawful Neutral
- **Size**: 80+ investigation specialists
- **Headquarters**: Training facilities, information centers
- **Leadership**: Council of investigation masters
- **Power Level**: Moderate (Investigation expertise)
- **Key Functions**: Investigation training, Method development, Case consultation
- **Major Conflicts**: Client confidentiality, Legal boundaries, Ethical standards
- **Investigation Specialization**: Method development, Training programs, Case analysis
- **Campaign Role**: Investigation training, Method consultation, Professional development
- **Adventure Levels**: 2-14
- **Allied Organizations**: Law enforcement, Academic institutions
- **Services**: Investigation training, Method consultation, Case analysis

---

## Cultural & Professional Groups

### Cultural Preservation Organizations

#### **[[The Harmony Collective]]** - Cultural Balance Organization
- **World**: Both
- **Type**: Cultural/Philosophical Organization
- **Alignment**: True Neutral
- **Size**: 200+ members across both worlds
- **Headquarters**: Cultural centers, harmony temples
- **Leadership**: Council of harmony masters
- **Power Level**: Moderate (Cultural influence)
- **Key Functions**: Cultural balance, Conflict mediation, Philosophical guidance
- **Major Conflicts**: Political pressure, Cultural changes, Philosophical differences
- **Cultural Focus**: Balance philosophy, Conflict resolution, Cultural preservation
- **Campaign Role**: Cultural mediators, Philosophical guides, Conflict resolution
- **Adventure Levels**: 1-12
- **Allied Organizations**: Cultural communities, Peace advocates
- **Cultural Services**: Meditation, Conflict mediation, Philosophical counseling

#### **[[The Verdant Accord]]** - Environmental Protection Alliance
- **World**: Aethermoor
- **Type**: Environmental Protection Organization
- **Alignment**: Neutral Good
- **Size**: 180+ environmental activists and specialists
- **Headquarters**: [[Sylvanheart]], environmental centers
- **Leadership**: Archdruid Thornweaver and environmental council
- **Power Level**: High (Environmental authority)
- **Key Functions**: Environmental protection, Nature preservation, Ecological balance
- **Major Conflicts**: Industrial development, Crystal expansion, Resource exploitation
- **Environmental Focus**: Forest protection, Crystal corruption prevention, Natural balance
- **Campaign Role**: Environmental allies, Nature guides, Conservation patrons
- **Adventure Levels**: 2-16
- **Allied Organizations**: Druidic communities, Environmental specialists
- **Environmental Services**: Conservation, Environmental restoration, Nature education

### Professional Service Organizations

#### **[[Current Riders Guild]]** - Aquatic Transportation Specialists
- **World**: Aquabyssos
- **Type**: Professional Transportation Guild
- **Alignment**: Lawful Neutral
- **Size**: 100+ current riders and support staff
- **Headquarters**: Current stations, transportation hubs
- **Leadership**: Guildmaster council
- **Power Level**: Moderate (Transportation control)
- **Key Functions**: Current transportation, Navigation services, Emergency rescue
- **Major Conflicts**: Safety regulations, Competition, Environmental changes
- **Transportation Specialization**: Current navigation, Underwater transportation, Emergency services
- **Campaign Role**: Transportation services, Navigation guides, Emergency assistance
- **Adventure Levels**: 1-10
- **Allied Organizations**: Maritime communities, Emergency services
- **Guild Services**: Current transportation, Navigation guidance, Emergency rescue

#### **[[Merchants Guild]]** - General Trade Organization
- **World**: Both
- **Type**: General Trading Guild
- **Alignment**: Lawful Neutral
- **Size**: 400+ merchants and traders
- **Headquarters**: Trading centers, merchant districts
- **Leadership**: Elected merchant council
- **Power Level**: High (Economic influence)
- **Key Functions**: Trade standards, Market protection, Commercial law
- **Major Conflicts**: Large corporations, Regulatory changes, Criminal infiltration
- **Trade Focus**: General commerce, Market standards, Small business protection
- **Campaign Role**: Trade services, Market information, Commercial allies
- **Adventure Levels**: 1-12
- **Allied Organizations**: Local businesses, Commercial communities
- **Guild Services**: Trade facilitation, Market information, Business protection

---

## Mysterious & Ancient Orders

### Secret Societies and Ancient Orders

#### **[[Order of the Shattered Crown]]** - Ancient Restoration Order
- **World**: Both
- **Type**: Secret Ancient Order
- **Alignment**: Lawful Neutral (Ancient agenda)
- **Size**: Unknown (estimated 50+ core members)
- **Headquarters**: Hidden ancient facilities
- **Leadership**: Council of Crown Keepers
- **Power Level**: High (Ancient knowledge)
- **Key Functions**: Crown restoration, Ancient knowledge preservation, Historical continuity
- **Major Conflicts**: Modern governments, Power structures, Historical secrecy
- **Ancient Purpose**: Imperial crown restoration, Ancient authority, Historical legitimacy
- **Secrets**: Crown shard locations, Ancient technologies, Historical truths
- **Campaign Role**: Ancient allies, Historical patrons, Legitimacy providers
- **Adventure Levels**: 8-20
- **Connected Organizations**: Ancient survivors, Historical scholars
- **Ancient Goals**: Crown restoration, Imperial legitimacy, Historical truth

#### **[[The Void Watchers]]** - Cosmic Horror Monitors
- **World**: Aquabyssos
- **Type**: Cosmic Horror Monitoring Organization
- **Alignment**: Lawful Neutral (Cosmic knowledge)
- **Size**: 40+ watchers and specialists
- **Headquarters**: Hidden observation posts
- **Leadership**: Council of cosmic observers
- **Power Level**: High (Cosmic knowledge)
- **Key Functions**: Cosmic threat monitoring, Reality stability, Horror prevention
- **Major Conflicts**: Cosmic entities, Reality instability, Knowledge burden
- **Cosmic Specialization**: Cosmic horror detection, Reality monitoring, Threat assessment
- **Campaign Role**: Cosmic advisors, Horror warnings, Reality guides
- **Adventure Levels**: 12-20
- **Allied Organizations**: Reality researchers, Academic specialists
- **Cosmic Responsibilities**: Reality protection, Horror prevention, Cosmic knowledge

### Reality Manipulation Organizations

#### **[[The Shadow Conspiracy]]** - Reality Control Network
- **World**: Aquabyssos
- **Type**: Shadow Reality Manipulation Network
- **Alignment**: Neutral Evil
- **Size**: Unknown (extensive infiltration)
- **Headquarters**: Shadow dimensions, hidden facilities
- **Leadership**: Shadow council (identities unknown)
- **Power Level**: Very High (Reality control)
- **Key Functions**: Reality manipulation, Shadow magic research, Control network
- **Major Conflicts**: Reality stability, Governmental authority, Public safety
- **Shadow Specialization**: Reality alteration, Shadow magic mastery, Control networks
- **Campaign Role**: Primary antagonists, Reality threats, Conspiracy targets
- **Adventure Levels**: 15-20
- **Allied Organizations**: Shadow Surgeons, Corrupt officials
- **Shadow Goals**: Reality control, Shadow dominance, Power consolidation

#### **[[The Parliament of Nobody]]** - Existential Void Organization
- **World**: Aquabyssos
- **Type**: Existential Void Cult
- **Alignment**: Chaotic Neutral (Void focus)
- **Size**: Unknown (existence questionable)
- **Headquarters**: Void spaces, non-existence
- **Leadership**: Parliament of non-entities
- **Power Level**: Unknown (Existential threat)
- **Key Functions**: Existence questioning, Reality negation, Void exploration
- **Major Conflicts**: Existence itself, Reality systems, Identity concepts
- **Void Specialization**: Existence negation, Identity erasure, Reality questioning
- **Campaign Role**: Existential threats, Reality challenges, Identity mysteries
- **Adventure Levels**: 16-20
- **Opposed Organizations**: Reality protection, Existence advocates
- **Existential Goals**: Reality questioning, Existence challenges, Identity negation

---

## Cross-Campaign Organizations

### Organizations Operating in Both Worlds

#### **[[Ancient Mer-Folk Empire]]** - Historical Predecessor
- **Worlds**: Both (Historical presence)
- **Type**: Ancient Imperial Organization
- **Alignment**: Lawful Neutral (Historical)
- **Size**: Historical empire (legacy influence)
- **Headquarters**: Ancient ruins, historical sites
- **Leadership**: Historical emperors (legacy influence)
- **Power Level**: Historical (Legacy influence)
- **Key Functions**: Historical precedent, Cultural foundation, Ancient knowledge
- **Modern Influence**: Cultural traditions, Ancient technologies, Historical legitimacy
- **Ancient Specialization**: Advanced underwater civilization, Ancient magic, Imperial governance
- **Campaign Role**: Historical reference, Ancient allies, Cultural foundation
- **Adventure Levels**: 5-18
- **Modern Organizations**: Historical scholars, Ancient survivors
- **Legacy Impact**: Cultural influence, Technological inheritance, Governmental precedent

#### **[[The Crimson Fleet]]** - Cross-World Maritime Force
- **Worlds**: Both
- **Type**: Maritime Military Organization
- **Alignment**: Chaotic Neutral
- **Size**: 200+ ships and crews
- **Headquarters**: Mobile fleet, hidden ports
- **Leadership**: Admiral council
- **Power Level**: High (Maritime force)
- **Key Functions**: Cross-world maritime operations, Naval warfare, Maritime control
- **Major Conflicts**: Official navies, Maritime law, Territorial disputes
- **Maritime Specialization**: Cross-world navigation, Naval combat, Maritime logistics
- **Campaign Role**: Maritime allies/enemies, Naval adventures, Cross-world connections
- **Adventure Levels**: 8-18
- **Allied Organizations**: Maritime communities, Independent territories
- **Maritime Operations: Cross-world shipping, Naval warfare, Maritime exploration

### Shared Knowledge Organizations

#### **[[The Forsaken Consortium Collective]]** - Multi-World Criminal Network
- **Worlds**: Both
- **Type**: Cross-World Criminal Organization
- **Alignment**: Neutral Evil
- **Size**: 300+ agents across both worlds
- **Headquarters**: Hidden facilities in both worlds
- **Leadership**: Cross-world criminal council
- **Power Level**: Very High (Cross-world influence)
- **Key Functions**: Cross-world crime, Resource trafficking, Information networks
- **Major Conflicts**: Law enforcement in both worlds, Territory disputes, Competition
- **Criminal Specialization**: Cross-world operations, Resource trafficking, Information control
- **Campaign Role**: Cross-world antagonists, Criminal services, Information networks
- **Adventure Levels**: 10-20
- **Allied Organizations**: Local criminal networks, Corrupt officials
- **Cross-World Crimes: Resource trafficking, Information smuggling, Corruption networks

---

## Power Level Analysis

### Tier 1 Organizations (World-Shaping Power)
**Very High Influence - National/International Level**

#### Government Powers
- **[[Parliament of Echoes]]** (Aquabyssos) - National legislative authority
- **[[The Crown Authority]]** (Aethermoor) - Royal governmental power
- **[[The Shadow Conspiracy]]** (Aquabyssos) - Reality manipulation network

#### Economic Powers  
- **[[Merchant Princes]]** (Aethermoor) - Commercial oligarchy control
- **[[Silverscale Consortium]]** (Aquabyssos) - Financial empire dominance
- **[[The Shadow Trade Network]]** (Aquabyssos) - Criminal economic empire

### Tier 2 Organizations (Regional Power)
**High Influence - Regional/Specialized Authority**

#### Military & Security
- **[[Crystal Wardens]]** (Aethermoor) - Elite military force
- **[[The Deepwatch Guard]]** (Aquabyssos) - Deep territory security
- **[[The Brotherhood of the Black Anchor]]** (Both) - Maritime criminal power

#### Religious & Cultural
- **[[Temple of Divine Order]]** (Aethermoor) - Official religious authority
- **[[The Verdant Accord]]** (Aethermoor) - Environmental protection alliance
- **[[The Void Watchers]]** (Aquabyssos) - Cosmic monitoring authority

### Tier 3 Organizations (Local/Specialized Power)
**Moderate Influence - Local Authority or Specialized Control**

#### Professional & Cultural
- **[[Master Artificers Guild]]** (Aethermoor) - Technological control
- **[[The Harmony Collective]]** (Both) - Cultural mediation authority
- **[[Current Riders Guild]]** (Aquabyssos) - Transportation specialization

#### Criminal & Underground
- **[[Independent Smugglers]]** (Both) - Underground commerce network
- **[[Shadowhaven Merchant Marine]]** (Aquabyssos) - Criminal transportation
- **[[The Whisper Syndicate]]** (Both) - Information crime network

### Tier 4 Organizations (Limited/Specialized Power)
**Low-Moderate Influence - Specialized or Limited Authority**

#### Academic & Knowledge
- **[[The Seekers' Guild]]** (Both) - Knowledge research specialization
- **[[Investigators Anonymous]]** (Universal) - Investigation training
- **[[The Convergence Seekers]]** (Both) - Reality research specialization

#### Cultural & Service
- **[[The Artisans' Collective of Master Crafters]]** (Both) - Craft quality control
- **[[Merchants Guild]]** (Both) - General trade standards
- **[[Goldspire Confederacy]]** (Aethermoor) - Independent city governance

---

## Relationship Network Maps

### Alliance Networks

#### **The Royal Alliance** (Aethermoor)
**Core Organizations:**
- The Crown Authority (Central authority)
- Crystal Wardens (Military support)
- Temple of Divine Order (Religious support)
- Merchant Princes (Economic support)

**Supporting Organizations:**
- Master Artificers Guild (Technological support)
- The Order of the Azure Flame (Mystical support)
- Local governance bodies

**Alliance Goals**: Royal stability, national defense, economic prosperity
**Alliance Tensions**: Queen's corruption, resource allocation, power balance

#### **The Imperial Coalition** (Aquabyssos)
**Core Organizations:**
- Parliament of Echoes (Legislative authority)
- The Deepwatch Guard (Military support)
- Regional governance bodies

**Supporting Organizations:**
- The Deepwater Trading Consortium (Economic support)
- Academic institutions (Knowledge support)
- Cultural organizations (Social support)

**Coalition Goals**: Imperial stability, territorial management, economic growth
**Coalition Tensions**: Corruption issues, regional autonomy, resource distribution

#### **The Criminal Underground** (Both Worlds)
**Core Organizations:**
- The Shadow Trade Network (Economic control)
- The Whisper Syndicate (Information control)
- Independent Smugglers (Transportation network)

**Supporting Organizations:**
- Shadow Surgeons Collective (Specialized services)
- The Brotherhood of the Black Anchor (Maritime operations)
- Local criminal gangs (Street-level operations)

**Underground Goals**: Profit maximization, territory expansion, law avoidance
**Underground Tensions**: Territory disputes, law enforcement pressure, competition

### Opposition Networks

#### **The Corruption Investigation Alliance**
**Investigating Organizations:**
- Reform movements in both governments
- Independent law enforcement
- Academic researchers
- Anti-corruption activists

**Target Organizations:**
- Parliament of Echoes (Shadow Chamber)
- Silverscale Consortium (Financial corruption)
- The Shadow Conspiracy (Reality manipulation)

#### **The Religious Conservative Coalition**
**Core Organizations:**
- Purist Coalition (Anti-crystal extremists)
- Orthodox religious institutions
- Traditional cultural groups

**Opposed Organizations:**
- Crystal-using communities
- Progressive religious movements
- Cultural change advocates

#### **The Environmental Protection Movement**
**Core Organizations:**
- The Verdant Accord (Primary leadership)
- Environmental protection groups
- Nature-focused religious orders

**Opposed Organizations:**
- Industrial development interests
- Crystal expansion advocates
- Resource extraction companies

### Neutral and Service Networks

#### **The Academic and Knowledge Network**
**Core Organizations:**
- The Seekers' Guild (Research coordination)
- Academic institutions (Knowledge creation)
- The Convergence Seekers (Specialized research)

**Service Focus**: Knowledge advancement, research coordination, information sharing
**Political Position**: Generally neutral, serving knowledge advancement

#### **The Professional Services Network**
**Core Organizations:**
- Professional guilds (Quality control)
- Service organizations (Professional standards)
- Cultural institutions (Community service)

**Service Focus**: Professional excellence, community service, cultural preservation
**Political Position**: Generally neutral, serving community needs

---

## Adventure Integration Framework

### Faction Conflict Scenarios

#### Political Intrigue Adventures
**Primary Factions**: Government organizations, Political movements, Power seekers
**Conflict Types**: Succession disputes, Corruption exposure, Policy conflicts
**Adventure Opportunities**: Diplomatic missions, Investigation adventures, Political maneuvering
**Player Roles**: Diplomatic agents, Investigators, Political advisors

#### Economic Warfare Adventures
**Primary Factions**: Commercial organizations, Criminal enterprises, Financial powers
**Conflict Types**: Trade wars, Economic manipulation, Market control
**Adventure Opportunities**: Commercial missions, Economic investigations, Trade protection
**Player Roles**: Economic agents, Trade representatives, Financial investigators

#### Religious and Cultural Conflicts
**Primary Factions**: Religious organizations, Cultural groups, Extremist movements
**Conflict Types**: Religious disputes, Cultural preservation, Extremist activities
**Adventure Opportunities**: Religious quests, Cultural missions, Extremist opposition
**Player Roles**: Religious agents, Cultural mediators, Community protectors

### Faction Service Opportunities

#### Government Service Adventures
**Providing Organizations**: Official government bodies, Military organizations, Law enforcement
**Service Types**: Official missions, Law enforcement, Military operations
**Adventure Rewards**: Official recognition, Government resources, Legal authority
**Service Requirements**: Loyalty oaths, Legal compliance, Professional conduct

#### Commercial Service Adventures
**Providing Organizations**: Trade guilds, Commercial enterprises, Economic powers
**Service Types**: Trade missions, Economic operations, Commercial protection
**Adventure Rewards**: Financial compensation, Trade privileges, Economic connections
**Service Requirements**: Professional competence, Contractual compliance, Commercial ethics

#### Criminal Service Adventures
**Providing Organizations**: Criminal networks, Underground organizations, Shadow groups
**Service Types**: Illegal operations, Underground missions, Shadow activities
**Adventure Rewards**: Underground resources, Criminal connections, Shadow knowledge
**Service Requirements**: Criminal skills, Moral flexibility, Loyalty to criminal codes

### Faction Relationship Development

#### Reputation Building Systems
- **Faction Standing**: Numerical tracking of relationships with organizations
- **Reputation Categories**: Professional, Political, Social, Criminal reputation types
- **Reputation Effects**: Access to services, Quest opportunities, Social reactions
- **Reputation Consequences**: Factional conflicts, Service limitations, Social challenges

#### Alliance and Opposition Management
- **Alliance Benefits**: Combined resources, Mutual protection, Coordinated operations
- **Opposition Consequences**: Active hostility, Resource denial, Coordinated resistance
- **Neutral Relations**: Professional interaction, Limited cooperation, Contractual relationships
- **Relationship Changes**: How player actions affect factional relationships over time

#### Long-Term Faction Evolution
- **Organizational Growth**: How factions expand influence and power over time
- **Leadership Changes**: How succession and leadership evolution affects factional relationships
- **Goal Achievement**: How factions pursue and achieve long-term objectives
- **Player Impact**: How character actions influence factional development and success

---

## Quick Reference Systems

### Faction Lookup by Adventure Type
- **Political Adventures**: Government bodies, Political movements, Power organizations
- **Military Adventures**: Military organizations, Security forces, War-focused groups
- **Commercial Adventures**: Trade organizations, Economic powers, Commercial enterprises
- **Criminal Adventures**: Criminal networks, Underground organizations, Illegal enterprises
- **Religious Adventures**: Religious institutions, Spiritual orders, Faith-based movements
- **Academic Adventures**: Research organizations, Knowledge institutions, Educational bodies
- **Cultural Adventures**: Cultural groups, Traditional organizations, Community institutions

### Faction Lookup by Power Level
- **World-Shaping**: National governments, Major criminal empires, Reality-altering organizations
- **Regional Control**: Regional authorities, Major guilds, Significant military forces
- **Local Authority**: City governments, Professional guilds, Community organizations
- **Specialized Power**: Expert organizations, Niche authorities, Specialized service providers

### Faction Lookup by World
- **Aethermoor Only**: The Crown Authority, Crystal Wardens, Merchant Princes, The Verdant Accord
- **Aquabyssos Only**: Parliament of Echoes, The Shadow Conspiracy, Shadow Trade Network
- **Both Worlds**: Ancient orders, Cross-world criminal networks, Academic institutions

### Faction Lookup by Alignment
- **Lawful Good**: Crystal Wardens, Temple of Divine Order, The Verdant Accord
- **Lawful Neutral**: Government bodies, Professional guilds, Academic institutions  
- **Lawful Evil**: Purist Coalition Thugs, Silverscale Consortium (corrupted)
- **Chaotic Good**: Some reform movements, Environmental activists
- **Chaotic Neutral**: Independent organizations, Maritime groups, Cultural movements
- **Chaotic Evil**: Criminal networks, Cult organizations, Extremist groups

---

## Related Master Indexes
- **[[Master_Places_Index|Master Places Index]]** - Location-Organization relationship mapping
- **[[Master_Lore_Index|Master Lore Index]]** - Historical and cultural organization connections  
- **[[Master_People_Index|Master People Index]]** - NPC-Organization leadership and membership relationships
- **[[Campaign_Relationship_Matrix|Campaign Relationship Matrix]]** - Comprehensive inter-organizational relationship system
- **[[Campaign_Quick_Reference_Sheets|Campaign Quick Reference Sheets]]** - Session-ready faction reference materials

---

*Master Groups Index - Complete*
*46 Organizations Catalogued and Cross-Referenced*  
*Faction Relationships Mapped Across Both Worlds*
*Power Analysis and Influence Networks Documented*
*Adventure Integration Framework Provided for All Organization Types*
*Agent 20 - Index Building Mission: 80% Complete*

## Cross-References

- [[Vault_Navigation_Hub|Vault Navigation Hub]]


## Orphaned Content

- [[02_Worldbuilding/Groups/Cultural Patro.md|Cultural Patro]]
- [[02_Worldbuilding/Groups/Shadowhawk Syndicat.md|Shadowhawk Syndicat]]
- [[02_Worldbuilding/Groups/Cultural Organization.md|Cultural Organization]]