# NPC-Location Relationship Matrix

Generated: 2025-08-13 07:58:19

## Nerissa_Deepcurrent (leader)

- [[02_Worldbuilding/Places/Pearl_Harbor_City]]

## Queen Seraphina (leader)

- [[The Royal Palace - Aquabyssos]]
- [[Academy of Deep Learning]]
- [[The Royal Palace - Aquabyssos]]

## The_Crimson_Pearl (leader)

- [[vault_backup_20250813_073007/02_Worldbuilding/Places/Market District]]
- [[vault_backup_20250813_073007/02_Worldbuilding/Places/Market District]]

