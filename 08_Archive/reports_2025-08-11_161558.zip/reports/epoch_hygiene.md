VAULT IMPROVEMENT PHASE 5: Epoch Harmonizer

Total files scanned: 1098
Files with mixed epochs: 6
Files changed: 467
World frontmatter added: 392

Changed files:
Updated: README_PHASE5.md
Updated: Vault_Navigation_Hub.md
Updated: Campaign_Dashboard.md
Updated: Master_Campaign_Index.md
Updated: World_Bible_Aquabyssos_Aethermoor.md
Updated: 1-Session Journals/Aquabyssos - Session 09 - The Mourning Strategy.md
Updated: 1-Session Journals/Aethermoor - Session 06 The Bloodline Awakens.md
Updated: 1-Session Journals/Aquabyssos - Session 07 - The Resonance Revelation.md
Updated: 1-Session Journals/Aethermoor - Session 04 The Silverscale Gambit.md
Updated: 1-Session Journals/Aquabyssos - Session 04 - High Tide Horror.md
Updated: 1-Session Journals/Aquabyssos - Session 08 - The Fractal Conspiracy.md
Updated: 1-Session Journals/Aethermoor - Session 10 The Deep Mother Rises.md
Updated: 1-Session Journals/Aethermoor - Session 05 The Queens Madness.md
Updated: 1-Session Journals/Aethermoor - Session 07 The Festival of Transformation.md
Updated: 1-Session Journals/Aethermoor - Session 09 The Price of Unity.md
Updated: 1-Session Journals/Aethermoor - Session 08 Between Two Worlds.md
Updated: 1-Session Journals/Aquabyssos - Session 05 - Descent into Darkness.md
Updated: 1-Session Journals/Aethermoor - Session 01 Blood in the Harbor.md
Updated: 1-Session Journals/Aethermoor - Session 03 Council of Shadows.md
Updated: 1-Session Journals/Aquabyssos - Session 01 - The Drowning Welcome.md
Updated: 1-Session Journals/Aquabyssos - Session 03 - The Gallery Conspiracy.md
Updated: 1-Session Journals/Aethermoor - Session 02 The Lighthouse of Storms.md
Updated: 1-Session Journals/Aquabyssos - Session 02 - The Parliament's Paradox.md
Updated: 1-Session Journals/Aquabyssos - Session 10 - The Shadow Finale.md
Updated: 1-Session Journals/Aquabyssos - Session 06 - The Silhouette Surgeons.md
Updated: 05_Templates/Templater/New Location.md
Updated: 05_Templates/Templater/New Quest.md
Updated: 05_Templates/Templater/New NPC.md
Updated: 05_Templates/Templater/New Session.md
Updated: 05_Templates/Text Generator Templates/Generate Campaign NPCs.md
Updated: 05_Templates/Text Generator Templates/Convert Monster.md
Updated: 05_Templates/World Builder Templates/Template-Player.md
Updated: 05_Templates/World Builder Templates/Template-Quest.md
Updated: 05_Templates/World Builder Templates/Template-Star-System.md
Updated: 05_Templates/World Builder Templates/Template-PointofInterest.md
Updated: 05_Templates/World Builder Templates/Template-Planet.md
Updated: 05_Templates/World Builder Templates/Template-Region.md
Updated: 05_Templates/World Builder Templates/Template-Journal.md
Updated: 05_Templates/World Builder Templates/Template-Player-Demiplane.md
Updated: 05_Templates/World Builder Templates/Template-Place.md
Updated: 05_Templates/World Builder Templates/Template-Galaxy.md
Updated: 05_Templates/World Builder Templates/Template-Group.md
Updated: 05_Templates/World Builder Templates/Template-Hub.md
Updated: 05_Templates/World Builder Templates/Template-Item.md
Updated: 05_Templates/World Builder Templates/Template-Person.md
Updated: 05_Templates/World Builder Templates/Template-Continent.md
Updated: 05_Templates/World Builder Templates/Template-SapientSpecies.md
Updated: 06_GM_Resources/Scene Framing Templates.md
Updated: 06_GM_Resources/Encounter_Builder.md
Updated: 06_GM_Resources/Session_Planning_Toolkit.md
Updated: 06_GM_Resources/NPC Quick Reference Guide.md
Updated: 06_GM_Resources/Campaign_Management_Guide.md
Updated: 06_GM_Resources/Reference Cards/Aquabyssos Quick Reference Cards.md
Updated: 07_Player_Resources/Rules_Reference.md
Updated: 07_Player_Resources/Character_Creation_Extended.md
Updated: 07_Player_Resources/Player_Portal.md
Updated: 07_Player_Resources/Quick_Start_Guide.md
Updated: 07_Player_Resources/Faction_Guide.md
Updated: 07_Player_Resources/World_Primer.md
Updated: 07_Player_Resources/Session_Summaries/Session Zero Universal Guide.md
Updated: 07_Player_Resources/Feedback/Player_Feedback_Form.md
Updated: 07_Player_Resources/Handouts/What You Know - Abyssos Prime.md
Updated: 07_Player_Resources/Handouts/Parliament of Shadows Player Guide.md
Updated: 04_Resources/Maps/Aquabyssos_World_Map.md
Updated: 04_Resources/Random_Tables/Aquabyssos Random Encounter Tables.md
Updated: 04_Resources/Random_Tables/Encounter_and_Loot_Generators.md
Updated: 04_Resources/Random_Tables/Abyssos Prime Rumor Tables.md
Updated: 1-DM Toolkit/Home Embeds.md
Updated: 1-DM Toolkit/Getting Started.md
Updated: 1-DM Toolkit/Button Templates.md
Updated: 1-DM Toolkit/Home Embeds - DV.md
Updated: 1-DM Toolkit/Home.md
Updated: 1-DM Toolkit/Vault Report.md
Updated: 1-DM Toolkit/DM Board.md
Updated: 1-DM Toolkit/Home - DV.md
Updated: 08_Archive/Reports/VAULT_COMPLETION_STATUS.md
Updated: 08_Archive/Reports/PROGRESS_REPORT_2025-08-10_SESSION3.md
Updated: 08_Archive/Reports/PROGRESS_REPORT_2025-08-10.md
Updated: 08_Archive/Reports/FINAL_STATUS_REPORT.md
Updated: 08_Archive/Reports/VAULT_COMPLETION_ROADMAP.md
Updated: 08_Archive/Reports/PROGRESS_REPORT_2025-08-10_SESSION2.md
Updated: 03_Mechanics/Comprehensive Survival System.md
Updated: 03_Mechanics/Depth Survival Mechanics.md
Updated: 03_Mechanics/Complete_Pressure_Adaptation_System.md
Updated: 03_Mechanics/Transformation_Compendium.md
Updated: 03_Mechanics/Complete_Faction_Warfare_System.md
Updated: 03_Mechanics/Aquabyssos Survival Mechanics.md
Updated: 03_Mechanics/Memory_Trading_Economy.md
Updated: 03_Mechanics/Complete_Reality_Merger_System.md
Updated: 03_Mechanics/Deep_Mother_Subsystem.md
Updated: 03_Mechanics/Depth Adaptation System.md
Updated: 03_Mechanics/Sanity_Horror_Framework.md
Updated: 03_Mechanics/Rules_Reference/Quick_Reference/DnD5e-SideScreen-2014.md
Updated: 03_Mechanics/Rules_Reference/Quick_Reference/DnD5e-SideScreen-2024.md
Updated: 03_Mechanics/Rules_Reference/Quick_Reference/DnD5e-DM Screen-2014.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Where To Get Mechanics.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Items/Harbor Master's Compass.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Items/Items.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Items/New Item.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Bestiary/Bestiary.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Bestiary/Aquabyssos Creature Compendium.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/Bestiary/Custom Homebrew Monster.md
Updated: 03_Mechanics/Rules_Reference/Homebrew/races/races.md
Updated: 02_Worldbuilding/Items/Shadow-touched Equipment Set.md
Updated: 02_Worldbuilding/Lore/Continental Connections & Story Weave.md
Updated: 02_Worldbuilding/Lore/The Sundering.md
Updated: 02_Worldbuilding/Lore/Aquabyssos World Overview.md
Updated: 02_Worldbuilding/Lore/The Real Marina.md
Updated: 02_Worldbuilding/Lore/Session 0 - Aquabyssos.md
Updated: 02_Worldbuilding/Lore/Echo of the Mother.md
Updated: 02_Worldbuilding/Lore/Investigation Procedures.md
Updated: 02_Worldbuilding/Lore/Citizens of Meridian.md
Updated: 02_Worldbuilding/Lore/Determine Aquabyssos.md
Updated: 02_Worldbuilding/Lore/Comprehensive-World-Connection-Guide.md
Updated: 02_Worldbuilding/Lore/Aquabyssos-Survival-Mechanics.md
Updated: 02_Worldbuilding/Lore/Aetheron.md
Updated: 02_Worldbuilding/Lore/Spell Components.md
Updated: 02_Worldbuilding/Lore/Aethermoor-Aquabyssos-World-Connection-Guide.md
Updated: 02_Worldbuilding/Lore/Pressure Tube Operator Krill.md
Updated: 02_Worldbuilding/Lore/Crimson Hand Strike Team.md
Updated: 02_Worldbuilding/Lore/Crystal Festival Grounds.md
Updated: 02_Worldbuilding/Lore/Sorrow Pearls.md
Updated: 02_Worldbuilding/Lore/Lamplight Alley.md
Updated: 02_Worldbuilding/Lore/Depth Adaptation Points.md
Updated: 02_Worldbuilding/Lore/The Great Crystallization.md
Updated: 02_Worldbuilding/Lore/The Seven Shards.md
Updated: 02_Worldbuilding/Lore/The Great Convergence Prophecies.md
Updated: 02_Worldbuilding/Lore/Corallion.md
Updated: 02_Worldbuilding/Lore/Thalassius the Wise.md
Updated: 02_Worldbuilding/Lore/Marina's Echo.md
Updated: 02_Worldbuilding/Lore/The Recursion Oracle.md
Updated: 02_Worldbuilding/Lore/Vorthak.md
Updated: 02_Worldbuilding/People/Jasper "Three-Eyes" Flint.md
Updated: 02_Worldbuilding/People/Shadow Broker Mist.md
Updated: 02_Worldbuilding/People/Captain Lyanna Brightshield.md
Updated: 02_Worldbuilding/People/Marina-Red-Tide-Coralheart.md
Updated: 02_Worldbuilding/People/Jasper Three-Eyes Flint.md
Updated: 02_Worldbuilding/People/Castellan Ironledger III.md
Updated: 02_Worldbuilding/People/Senator_Glaucus_Brain.md
Updated: 02_Worldbuilding/People/Gareth_Ironforge.md
Updated: 02_Worldbuilding/People/Master Cultivator Thalia Greenglow.md
Updated: 02_Worldbuilding/People/Archon Meredith Saltweaver.md
Updated: 02_Worldbuilding/People/High Inquisitor Maltheos.md
Updated: 02_Worldbuilding/People/Marcus "The Shade" Blackwood.md
Updated: 02_Worldbuilding/People/Brother Marcus Steelbane.md
Updated: 02_Worldbuilding/People/Sage Lysander Deepthought.md
Updated: 02_Worldbuilding/People/Abyssal Cathedral.md
Updated: 02_Worldbuilding/People/Queen Seraphina Lumengarde.md
Updated: 02_Worldbuilding/People/Throne of Bubbles.md
Updated: 02_Worldbuilding/People/The Scattered Emperor.md
Updated: 02_Worldbuilding/People/The Emperor.md
Updated: 02_Worldbuilding/People/Oracle.md
Updated: 02_Worldbuilding/People/Senator Glaucus.md
Updated: 02_Worldbuilding/People/Korvin Blacktide.md
Updated: 02_Worldbuilding/People/The Bloodline Carrier.md
Updated: 02_Worldbuilding/People/Archbishop Mordecai Stormwright.md
Updated: 02_Worldbuilding/People/The Tidecaller.md
Updated: 02_Worldbuilding/People/The Resonance Prophet.md
Updated: 02_Worldbuilding/People/Emperor Thalassius.md
Updated: 02_Worldbuilding/People/Harbor Master Luna Freedrift.md
Updated: 02_Worldbuilding/People/The Cerulean Breath.md
Updated: 02_Worldbuilding/People/Nerissa_Deepcurrent.md
Updated: 02_Worldbuilding/People/Emperor Thalassius the Wise.md
Updated: 02_Worldbuilding/People/Patriarch Valdris Lightbringer.md
Updated: 02_Worldbuilding/People/High Priestess Scylla Deepdream.md
Updated: 02_Worldbuilding/People/Vex Shadowthorn.md
Updated: 02_Worldbuilding/People/Zephyr Goldwhisper.md
Updated: 02_Worldbuilding/People/Captain Scale-Walker.md
Updated: 02_Worldbuilding/People/Captain Nautilus the Deep Wanderer.md
Updated: 02_Worldbuilding/People/Sister Morwyn Veilkeeper.md
Updated: 02_Worldbuilding/People/Banker Titus Goldcurrent.md
Updated: 02_Worldbuilding/People/Parliament Loyalists.md
Updated: 02_Worldbuilding/People/Duchess Marina Ever-Drowning.md
Updated: 02_Worldbuilding/People/Admiral Thorne Blackwater.md
Updated: 02_Worldbuilding/People/The_Crimson_Pearl.md
Updated: 02_Worldbuilding/People/Ambassador Nerida Deepcurrent.md
Updated: 02_Worldbuilding/People/Senator Marius.md
Updated: 02_Worldbuilding/People/His Own Shadow.md
Updated: 02_Worldbuilding/People/Aria Lumengarde.md
Updated: 02_Worldbuilding/People/Professor Aldric Crystalweaver.md
Updated: 02_Worldbuilding/People/Lighthouse Keeper.md
Updated: 02_Worldbuilding/People/Prince Caspian Duskwater.md
Updated: 02_Worldbuilding/People/Aboleth Prime Yoth.md
Updated: 02_Worldbuilding/People/Archdruid Thornweaver.md
Updated: 02_Worldbuilding/People/The Crimson Sage.md
Updated: 02_Worldbuilding/People/The Senator.md
Updated: 02_Worldbuilding/People/Marcus Shardbreaker Grimm.md
Updated: 02_Worldbuilding/People/Original Glaucus.md
Updated: 02_Worldbuilding/People/High Cultivist Jasper Lifebinder.md
Updated: 02_Worldbuilding/People/Ambassador Korvin Blacktide.md
Updated: 02_Worldbuilding/People/Master Artificer Korvin Gearwright.md
Updated: 02_Worldbuilding/People/Envoy Blackwater Jr..md
Updated: 02_Worldbuilding/People/Elder Whisper-In-The-Dark.md
Updated: 02_Worldbuilding/People/High Priest Dagon Deepcaller.md
Updated: 02_Worldbuilding/People/Sorrow-Root Nightbloom.md
Updated: 02_Worldbuilding/People/Lord Commander Gareth Steelborn.md
Updated: 02_Worldbuilding/People/Knight.md
Updated: 02_Worldbuilding/People/Tenebrarum.md
Updated: 02_Worldbuilding/People/Duke Cyrus Reefheart.md
Updated: 02_Worldbuilding/People/Doctor Helena Voidwalker.md
Updated: 02_Worldbuilding/People/Shadow Duchess Nyx.md
Updated: 02_Worldbuilding/People/The Silhouette Surgeon Prime.md
Updated: 02_Worldbuilding/People/Empress Tethys the Ever-Drowning.md
Updated: 02_Worldbuilding/People/Mayor Thompson.md
Updated: 02_Worldbuilding/People/Marina Red Tide Coralheart - Aquabyssos.md
Updated: 02_Worldbuilding/People/Prophet Nerida Voidgazer.md
Updated: 02_Worldbuilding/People/Assassin.md
Updated: 02_Worldbuilding/People/Senator.md
Updated: 02_Worldbuilding/People/The Biomancers.md
Updated: 02_Worldbuilding/People/Captain Marrow Drinker.md
Updated: 02_Worldbuilding/People/The Sorrowmaster.md
Updated: 02_Worldbuilding/People/The Barnacle.md
Updated: 02_Worldbuilding/People/High Priestess Celeste Dawnbringer.md
Updated: 02_Worldbuilding/People/Tenebrarum Ambassadors.md
Updated: 02_Worldbuilding/People/Enforcer Chief Mako Ironjaw.md
Updated: 02_Worldbuilding/People/Captain Blackwater.md
Updated: 02_Worldbuilding/People/Unite the Emperor.md
Updated: 02_Worldbuilding/People/Captain Garrett Stormcutter.md
Updated: 02_Worldbuilding/People/Master of Currents Zephyr.md
Updated: 02_Worldbuilding/People/Admiral Cassandra Stormwind.md
Updated: 02_Worldbuilding/People/Sir Marcus Dawnforge.md
Updated: 02_Worldbuilding/People/Captain Thaddeus Blackwater.md
Updated: 02_Worldbuilding/Quests/Quest - Smuggler's Run.md
Updated: 02_Worldbuilding/Quests/Depths of Whispers.md
Updated: 02_Worldbuilding/Quests/Smuggler.md
Updated: 02_Worldbuilding/Quests/Quest - Diplomatic Immunity.md
Updated: 02_Worldbuilding/Quests/Ambush Point.md
Updated: 02_Worldbuilding/Quests/Quest - The Seventh Shard.md
Updated: 02_Worldbuilding/Quests/The Lock Saboteur.md
Updated: 02_Worldbuilding/Quests/Traveling Merchant Finn.md
Updated: 02_Worldbuilding/Quests/Find the Grief Bomb.md
Updated: 02_Worldbuilding/Quests/The Tide Rises.md
Updated: 02_Worldbuilding/Quests/The Depth Accords.md
Updated: 02_Worldbuilding/Quests/Bandit Scouts.md
Updated: 02_Worldbuilding/Quests/Quest - The Crystal Black Market.md
Updated: 02_Worldbuilding/Quests/Smuggler's Gambit.md
Updated: 02_Worldbuilding/Quests/Quest - The Lost Expedition.md
Updated: 02_Worldbuilding/Quests/Quest - The Plague of Crystals.md
Updated: 02_Worldbuilding/Quests/Quest - The Seventh Seal.md
Updated: 02_Worldbuilding/Quests/Bandit Leader Scarface.md
Updated: 02_Worldbuilding/Quests/The Maw of Darkness.md
Updated: 02_Worldbuilding/Quests/The Green Death.md
Updated: 02_Worldbuilding/Quests/Caravan Master Dolrim.md
Updated: 02_Worldbuilding/Quests/Quest - The Drowned Prophecy.md
Updated: 02_Worldbuilding/Quests/Find_the_Missing_Caravan.md
Updated: 02_Worldbuilding/Quests/The_Second_Rising.md
Updated: 02_Worldbuilding/Quests/Quest - Hearts and Minds.md
Updated: 02_Worldbuilding/Quests/Crystalline Depths.md
Updated: 02_Worldbuilding/Quests/Aquabyssos.md
Updated: 02_Worldbuilding/Quests/Rescue Senator Glaucus.md
Updated: 02_Worldbuilding/Quests/Economic Warfare.md
Updated: 02_Worldbuilding/Places/Shadow Merchant Riptide.md
Updated: 02_Worldbuilding/Places/Surface Tensions.md
Updated: 02_Worldbuilding/Places/Inquisitor Mordecai Truthseeker.md
Updated: 02_Worldbuilding/Places/Reef Guard Captain Torrent Shellborn.md
Updated: 02_Worldbuilding/Places/Gallery of Frozen Waves.md
Updated: 02_Worldbuilding/Places/Scout Captain Vera Deepwatch.md
Updated: 02_Worldbuilding/Places/The Cerulean Archipelago.md
Updated: 02_Worldbuilding/Places/Whisper-Touched William.md
Updated: 02_Worldbuilding/Places/Chef Amara Tastecurrent.md
Updated: 02_Worldbuilding/Places/The Deepwater Current.md
Updated: 02_Worldbuilding/Places/The Depth Market.md
Updated: 02_Worldbuilding/Places/The Foundation Depths.md
Updated: 02_Worldbuilding/Places/Aboleth Adjunct Yzz.md
Updated: 02_Worldbuilding/Places/Aethermoor.md
Updated: 02_Worldbuilding/Places/Crystalhaven.md
Updated: 02_Worldbuilding/Places/Surface Portal Alpha.md
Updated: 02_Worldbuilding/Places/The Wandering Atoll.md
Updated: 02_Worldbuilding/Places/New Thalassopolis.md
Updated: 02_Worldbuilding/Places/The Last Priest.md
Updated: 02_Worldbuilding/Places/The Temporal Convergence Storms.md
Updated: 02_Worldbuilding/Places/The Verdant Reach.md
Updated: 02_Worldbuilding/Places/The Suicide Bridges.md
Updated: 02_Worldbuilding/Places/The Cerulean Trench.md
Updated: 02_Worldbuilding/Places/Abyssos Prime Upper Districts.md
Updated: 02_Worldbuilding/Places/Merchant Viktor Geargrind.md
Updated: 02_Worldbuilding/Places/Pressure Terminal.md
Updated: 02_Worldbuilding/Places/The Eternal Senate.md
Updated: 02_Worldbuilding/Places/The Primordial Vaults.md
Updated: 02_Worldbuilding/Places/Barkeep Mira Algaebrew.md
Updated: 02_Worldbuilding/Places/The Infinite Garden.md
Updated: 02_Worldbuilding/Places/Keeper of the Dead, Sister Morwyn.md
Updated: 02_Worldbuilding/Places/Inverted Ballroom Wing.md
Updated: 02_Worldbuilding/Places/Lucky Finn Dicetide.md
Updated: 02_Worldbuilding/Places/The Bone Palace of Sorrows.md
Updated: 02_Worldbuilding/Places/Royal Vault.md
Updated: 02_Worldbuilding/Places/Engineer Prisma Depthwright.md
Updated: 02_Worldbuilding/Places/The Sunken Markets.md
Updated: 02_Worldbuilding/Places/The Singing Trenches.md
Updated: 02_Worldbuilding/Places/Smuggler's Cove.md
Updated: 02_Worldbuilding/Places/Anti-Priest Nullus.md
Updated: 02_Worldbuilding/Places/Merchant Delilah Currentrunner.md
Updated: 02_Worldbuilding/Places/Old Valdris.md
Updated: 02_Worldbuilding/Places/Keeper of the Past, Elderly Morgan.md
Updated: 02_Worldbuilding/Places/The Phosphor Markets.md
Updated: 02_Worldbuilding/Places/The Screaming Battleground.md
Updated: 02_Worldbuilding/Places/The Crystal Hive Collective.md
Updated: 02_Worldbuilding/Places/Merchant Prince Akula.md
Updated: 02_Worldbuilding/Places/Royal Palace.md
Updated: 02_Worldbuilding/Places/Healer Sage Bondseer.md
Updated: 02_Worldbuilding/Places/Navigator Flux.md
Updated: 02_Worldbuilding/Places/Pressure Tubes.md
Updated: 02_Worldbuilding/Places/Teacher Miranda Hopekeeper.md
Updated: 02_Worldbuilding/Places/Madame Whisper.md
Updated: 02_Worldbuilding/Places/Ancient Tunnels Beneath Palace.md
Updated: 02_Worldbuilding/Places/Harbor Master Luna Freedrift.md
Updated: 02_Worldbuilding/Places/Coral Throne Syndicate.md
Updated: 02_Worldbuilding/Places/The Void Touched Depths.md
Updated: 02_Worldbuilding/Places/Abyssos Prime.md
Updated: 02_Worldbuilding/Places/The Golden Trade Route.md
Updated: 02_Worldbuilding/Places/Dream Rails.md
Updated: 02_Worldbuilding/Places/Seamstress Coral Silkweaver.md
Updated: 02_Worldbuilding/Places/Navigator Sage Driftwood.md
Updated: 02_Worldbuilding/Places/The Sundered Peaks.md
Updated: 02_Worldbuilding/Places/Court Herald Titus.md
Updated: 02_Worldbuilding/Places/Abyssos Prime Docks.md
Updated: 02_Worldbuilding/Places/The Memory Meadows Black Market.md
Updated: 02_Worldbuilding/Places/Captain Marcus.md
Updated: 02_Worldbuilding/Places/The Crystal Merchant.md
Updated: 02_Worldbuilding/Places/The Whispering Depths.md
Updated: 02_Worldbuilding/Places/Lumengarde.md
Updated: 02_Worldbuilding/Places/Siren Maeve Echoborn.md
Updated: 02_Worldbuilding/Places/World Map.md
Updated: 02_Worldbuilding/Places/The Crystal Stock Exchange.md
Updated: 02_Worldbuilding/Places/Innkeeper Mara Ironlung.md
Updated: 02_Worldbuilding/Places/The Neutral Current Tavern.md
Updated: 02_Worldbuilding/Places/Mourning Depths.md
Updated: 02_Worldbuilding/Places/Artisan Felix Reefwright.md
Updated: 02_Worldbuilding/Places/Parliament of Echoes.md
Updated: 02_Worldbuilding/Places/Innkeeper Marina Dreamwhisper.md
Updated: 02_Worldbuilding/Places/Church of the Tidal Throne.md
Updated: 02_Worldbuilding/Places/Tethyan Hegemony.md
Updated: 02_Worldbuilding/Places/The Shadowmere.md
Updated: 02_Worldbuilding/Places/The Free Current.md
Updated: 02_Worldbuilding/Places/Old Sally Seasprayer.md
Updated: 02_Worldbuilding/Places/Pearl_Harbor_City.md
Updated: 02_Worldbuilding/Places/Forge of War.md
Updated: 02_Worldbuilding/Places/Supplier Erikson Tidecaller.md
Updated: 02_Worldbuilding/Places/Memoriam.md
Updated: 02_Worldbuilding/Places/The Shadow Markets New.md
Updated: 02_Worldbuilding/Places/Gatekeeper Iron-Lung Boris.md
Updated: 02_Worldbuilding/Places/Abyssos Prime - Pressure Terminal.md
Updated: 02_Worldbuilding/Places/The Frozen Throne.md
Updated: 02_Worldbuilding/Places/The Sundered Vaults.md
Updated: 02_Worldbuilding/Places/Memoriam - The Forgotten Continent.md
Updated: 02_Worldbuilding/Places/Temporal Navigation.md
Updated: 02_Worldbuilding/Places/Courier Chief Swift Currentrider.md
Updated: 02_Worldbuilding/Places/Temple Guardian Marcus the Drowned.md
Updated: 02_Worldbuilding/Places/Beast Master Krell Chainbreaker.md
Updated: 02_Worldbuilding/Places/Void Currents.md
Updated: 02_Worldbuilding/Places/Goldspire Port.md
Updated: 02_Worldbuilding/Places/Angels and Depths.md
Updated: 02_Worldbuilding/Places/Memory Farmer Thane.md
Updated: 02_Worldbuilding/Places/Theological Warfare.md
Updated: 02_Worldbuilding/Places/The Bone Colosseum.md
Updated: 02_Worldbuilding/Places/Liminal Constantinople.md
Updated: 02_Worldbuilding/Places/The Deep Fugitive.md
Updated: 02_Worldbuilding/Places/The Neutral Ground.md
Updated: 02_Worldbuilding/Places/The Memory Meadows.md
Updated: 02_Worldbuilding/Places/Pressure's End.md
Updated: 02_Worldbuilding/Places/The Harbor Depths.md
Updated: 02_Worldbuilding/Places/The Silent Watcher.md
Updated: 02_Worldbuilding/Places/Pressure Tube Terminal.md
Updated: 02_Worldbuilding/Places/Throne Room - Heart of Palace.md
Updated: 02_Worldbuilding/Places/The Bathyal Palace.md
Updated: 02_Worldbuilding/Places/The Pressure Conspiracy.md
Updated: 02_Worldbuilding/Places/Envoy Blackwater Jr..md
Updated: 02_Worldbuilding/Places/Lord Reginald Seaworthy.md
Updated: 02_Worldbuilding/Places/Lady Vivienne the Unfrozen.md
Updated: 02_Worldbuilding/Places/Azure Citadel.md
Updated: 02_Worldbuilding/Places/Noble Quarter.md
Updated: 02_Worldbuilding/Places/Elder Whisper-In-The-Dark.md
Updated: 02_Worldbuilding/Places/The Forgotten Representative.md
Updated: 02_Worldbuilding/Places/The Depth Plague.md
Updated: 02_Worldbuilding/Places/The Shattered Sanctum.md
Updated: 02_Worldbuilding/Places/Whisper Island Docks.md
Updated: 02_Worldbuilding/Places/Keeper of Contracts Minerva Bindingword.md
Updated: 02_Worldbuilding/Places/Harbor District Customs House.md
Updated: 02_Worldbuilding/Places/Enchanter Valdris Peacewarden.md
Updated: 02_Worldbuilding/Places/Screaming Gardens.md
Updated: 02_Worldbuilding/Places/The Hidden Cove of Whispers.md
Updated: 02_Worldbuilding/Places/Commander Typhoon Blackheart.md
Updated: 02_Worldbuilding/Places/Crystal Gardens.md
Updated: 02_Worldbuilding/Places/The First Failure.md
Updated: 02_Worldbuilding/Places/Luminous Hollow.md
Updated: 02_Worldbuilding/Places/Blood Current Express.md
Updated: 02_Worldbuilding/Places/Palace Courtyard - Crystal Garden.md
Updated: 02_Worldbuilding/Places/Vault Keeper Eternal.md
Updated: 02_Worldbuilding/Places/The Mourning Depths.md
Updated: 02_Worldbuilding/Places/Mediator Serenity Stillwater.md
Updated: 02_Worldbuilding/Places/Mad Oracle Thessaly.md
Updated: 02_Worldbuilding/Places/Archivist Vera Glowmind.md
Updated: 02_Worldbuilding/Places/The Floating Markets of Nereidios.md
Updated: 02_Worldbuilding/Places/Illyana Glowstream.md
Updated: 02_Worldbuilding/Places/The Archive of Unremembered Things.md
Updated: 02_Worldbuilding/Places/Bubble Burst.md
Updated: 02_Worldbuilding/Places/Merchant.md
Updated: 02_Worldbuilding/Places/The Recursion Cult.md
Updated: 02_Worldbuilding/Places/The Kraken's Harbor.md
Updated: 02_Worldbuilding/Places/Temple Ward.md
Updated: 02_Worldbuilding/Places/The Grand Bazaar of Echoing Coins.md
Updated: 02_Worldbuilding/Places/Concierge Phillip Gracewater.md
Updated: 02_Worldbuilding/Places/Current Riders Guild.md
Updated: 02_Worldbuilding/Places/The Crystalline Foundry.md
Updated: 02_Worldbuilding/Places/The Crimson Foundries.md
Updated: 02_Worldbuilding/Places/The Slave Markets of Tethys.md
Updated: 02_Worldbuilding/Places/Market_District.md
Updated: 02_Worldbuilding/Places/Master Smith Vulcan Deepforge.md
Updated: 02_Worldbuilding/Places/The Temple of Eternal Tides.md
Updated: 02_Worldbuilding/Places/Ambassador Lysandra Silvertonge.md
Updated: 02_Worldbuilding/Places/Nereidios.md
Updated: 02_Worldbuilding/Places/The Lock.md
Updated: 02_Worldbuilding/Places/Port Meridian.md
Updated: 02_Worldbuilding/Places/The Inverse Palace.md
Updated: 02_Worldbuilding/Places/Harbormaster Erik Saltbeard.md
Updated: 02_Worldbuilding/Places/The Crystal Cathedral of Pure Light.md
Updated: 02_Worldbuilding/Places/The Sorrow Current.md
Updated: 02_Worldbuilding/Places/The Iron Pits of Malachar.md
Updated: 02_Worldbuilding/Places/Memory Merchant Zephyr Mindweaver.md
Updated: 02_Worldbuilding/Places/Harbor District.md
Updated: 02_Worldbuilding/Places/Doctor Coral Shapeshift.md
Updated: 02_Worldbuilding/Places/The Vanishing Depths.md
Updated: 02_Worldbuilding/Places/Amnesia Gallery.md
Updated: 02_Worldbuilding/Places/The Synthesis Gardens.md
Updated: 02_Worldbuilding/Places/The Sunken Cathedral of Stars.md
Updated: 02_Worldbuilding/Places/The Memory Thief.md
Updated: 02_Worldbuilding/Places/Chef Gastropod.md
Updated: 02_Worldbuilding/Places/Battle Priest Cassius Depthshield.md
Updated: 02_Worldbuilding/Places/The Drowned Embassy.md
Updated: 02_Worldbuilding/Places/Warden Marcus Stonehand.md
Updated: 02_Worldbuilding/Places/Sister Morwyn.md
Updated: 02_Worldbuilding/Places/New Tethys.md
Updated: 02_Worldbuilding/Places/Abyssos Prime - Inverse Palace.md
Updated: 02_Worldbuilding/Places/Keeper Elara Mindwell.md
Updated: 02_Worldbuilding/Groups/The Crimson Tide Pirates.md
Updated: 02_Worldbuilding/Groups/Independent Smugglers.md
Updated: 02_Worldbuilding/Groups/The Seekers' Guild.md
Updated: 02_Worldbuilding/Groups/Port Sorrow Trading Company.md
Updated: 02_Worldbuilding/Groups/Purist Coalition.md
Updated: 02_Worldbuilding/Groups/The Whisper Syndicate.md
Updated: 02_Worldbuilding/Groups/The Brotherhood of the Black Anchor.md
Updated: 02_Worldbuilding/Groups/The Crimson Fleet.md
Updated: 02_Worldbuilding/Groups/The Deepwater Trading Consortium.md
Updated: 02_Worldbuilding/Groups/The Leviathan Cult.md
Updated: 02_Worldbuilding/Groups/The Shadow Trade Network.md
Updated: 02_Worldbuilding/Groups/The Shadowhaven Smugglers Ring.md
Updated: 02_Worldbuilding/Groups/The Shadow War Coalition.md
Updated: 02_Worldbuilding/Groups/The Artisans' Collective of Master Crafters.md
Updated: 02_Worldbuilding/Groups/Merchant's Covenant.md
Updated: 02_Worldbuilding/Groups/The Crystal Throne.md
Updated: 02_Worldbuilding/Groups/Bexley Port Authority.md
Updated: 02_Worldbuilding/Groups/Merchant Princes.md
Updated: 02_Worldbuilding/Groups/The Carrion Court.md
Updated: 02_Worldbuilding/Groups/Crystal Wardens.md
Updated: 02_Worldbuilding/Groups/Aquabyssos Faction Web.md
Updated: 02_Worldbuilding/Groups/Order of the Drowned Star.md
Updated: 02_Worldbuilding/Groups/Temple of Divine Order.md
Updated: 02_Worldbuilding/Groups/Dockworkers Union.md
Updated: 02_Worldbuilding/Groups/Thieves Guild.md
Updated: 02_Worldbuilding/Groups/The Forsaken Consortium Collective.md
Updated: 02_Worldbuilding/Groups/Shadow Surgeons Collective.md
Updated: 02_Worldbuilding/Groups/Cult of Screams.md
Updated: 02_Worldbuilding/Groups/Investigators Anonymous.md
Updated: 02_Worldbuilding/Groups/Merchants Guild.md
Updated: 02_Worldbuilding/Groups/Shadowhaven Merchant Marine.md
Updated: 02_Worldbuilding/Groups/The Order of the Azure Flame.md
Updated: 09_Performance/Indexes/Campaign_Index.md
