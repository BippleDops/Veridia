---
title: "Player Handout \u2014 D-201 Abyss Mirror Lake"
type: handout
status: complete
audience: player
tags:
- both
- complete
- depth
- encounter
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.199917+00:00'
world: Both
---


# Abyss Mirror Lake

The water ahead lies too still. In it, you see a sky that isn’t yours.

What you notice
- Ripples that move before you do
- A reflection that arrives late

What you can try
- Approach with care
- Keep voices low; listen

Possible outcomes
- A safe path reveals itself
- The mirror ripples wrong
- Something in the reflection looks back

## Cross-References

- [[Aquabyssos_Session_01|06 GM Resources/Session Packets/Aquabyssos Session 01]]
