---
title: "Player Handout \u2014 M-201 Event Horizon Shear"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- merger
created: '2025-08-11'
updated: '2025-08-13T01:18:37.204254+00:00'
world: Both
---


# Event Horizon Shear

A black ring cuts across the sky like a halo with teeth. Lines on the deck don’t meet.

What you notice
- Rigging shadows out of step
- A tug sideways where nothing is

What you can try
- Keep the anchor hymn steady
- Move slowly; call your steps

Possible outcomes
- You pass cleanly
- A spar tears away into silence
- The ship lurches and someone falls
