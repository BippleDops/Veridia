---
title: "Player Handout \u2014 Reality Control Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.198280+00:00'
world: Both
---


# Reality Control

How it feels
- Calm lanes; hymns at checkpoints; the world behaves

What changes in travel
- Severity drops near you; cadence puzzles crop up

Crew tips
- Keep an anchor kit ready; practice the chant

Risks
- If your song falters, the backlash is sharp

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
