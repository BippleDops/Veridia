---
title: "Player Handout \u2014 Pirate Confederacy Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.195733+00:00'
world: Both
---


# Pirate Confederacy

How it feels
- Signals, grins, and deals; danger with rules

What changes in travel
- More nets, mines, and parley; privateers shape lanes

Crew tips
- Read the flags; keep a fallback promise ready

Risks
- A deal can turn with the wind

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
