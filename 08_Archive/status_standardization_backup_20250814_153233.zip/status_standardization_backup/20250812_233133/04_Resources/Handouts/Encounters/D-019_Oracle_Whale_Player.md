---
title: "Player Handout \u2014 D-019 Oracle Whale"
type: handout
status: complete
audience: player
tags:
- both
- complete
- depth
- encounter
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.201749+00:00'
world: Both
---


# Oracle Whale

A song like a mountain moves through you. Meanings hang in the water, waiting to be understood.

What you feel
- The hull vibrates with each note
- A strange calm—or fear—settles in

What you can try
- Listen closely and interpret
- Record the song
- Ward off poachers, if any

Possible outcomes
- You carry an omen forward
- The meaning slips away
- The truth is heavier than you hoped

## Cross-References

- [[Aquabyssos_Session_01|06 GM Resources/Session Packets/Aquabyssos Session 01]]
