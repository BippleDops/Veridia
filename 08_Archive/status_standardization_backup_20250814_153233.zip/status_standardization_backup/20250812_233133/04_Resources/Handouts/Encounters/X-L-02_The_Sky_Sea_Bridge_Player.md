---
title: "Player Handout \u2014 X-L-02 The Sky\u2013Sea Bridge"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.202844+00:00'
world: Both
---


# The Sky–Sea Bridge

A road appears where there was only air and pressure and hope.

What you notice
- A hum that matches your heartbeat
- Steps that feel like flying

What you can try
- Walk steady and sing
- Watch the edges

Possible outcomes
- A new way opens
- It sways
- It breaks
