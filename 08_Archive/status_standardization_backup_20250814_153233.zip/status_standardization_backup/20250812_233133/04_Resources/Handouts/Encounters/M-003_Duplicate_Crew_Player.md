---
title: "Player Handout \u2014 M-003 Duplicate Crew Arrival"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- merger
created: '2025-08-11'
updated: '2025-08-13T01:18:37.201277+00:00'
world: Both
---


# Duplicate Crew Arrival

The hatch opens and you walk in—soaked, shaking, claiming to be five minutes ahead of yourself.

What you notice
- Clothes and gear slightly wrong
- A story that matches yours—almost

What you can try
- Keep calm and talk
- Check details
- Keep the ship safe while you decide

Possible outcomes
- Two versions of you work together
- Tense standoff
- A fight you didn’t want
