---
title: "Player Handout \u2014 S-009 Void Moan"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- sky
created: '2025-08-11'
updated: '2025-08-13T01:18:37.206157+00:00'
world: Both
---


# Void Moan

The wind stops. A pressure like silence pushes against your thoughts.

What you feel
- Ringing in the ears
- A sudden sense of being very small

What you can try
- Steady each other with a song or prayer
- Keep busy at your post

Possible outcomes
- You shrug it off together
- Someone freezes up
- The quiet gets inside

## Cross-References

- [[Aethermoor_Session_01|06 GM Resources/Session Packets/Aethermoor Session 01]]
