---
title: "Player Handout \u2014 X-L-12 The Deep Mother\u2019s Bridge of Dreams"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.205700+00:00'
world: Both
---


# The Deep Mother’s Bridge of Dreams

A bridge woven from song and sleep stretches between worlds.

What you notice
- Footsteps that leave ripples
- A lullaby you almost remember

What you can try
- Accept the blessing
- Keep your name close

Possible outcomes
- You cross and are changed
- You cross and are shaken
- You do not cross
