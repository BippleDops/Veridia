---
title: "Player Handout \u2014 Guerrilla Currents Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.197226+00:00'
world: Both
---


# Guerrilla Currents

How it feels
- Riding edges; sudden turns; slick smiles

What changes in travel
- Current and jet tricks; patrols lose you

Crew tips
- Sensor calls seams; Helm surfs

Risks
- Miss the seam and you tumble

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
