---
title: "Player Handout \u2014 M-008 Door Opens Elsewhere"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- merger
created: '2025-08-11'
updated: '2025-08-13T01:18:37.203334+00:00'
world: Both
---


# Door Opens Elsewhere

The maintenance door opens onto a cliff under twin moons.

What you notice
- Night air that smells wrong
- Distant lights where no lights should be

What you can try
- Hold the door
- Tie a safety line
- Peek—or step through

Possible outcomes
- You close it and move on
- Something comes through
- You find a shortcut—or a detour
