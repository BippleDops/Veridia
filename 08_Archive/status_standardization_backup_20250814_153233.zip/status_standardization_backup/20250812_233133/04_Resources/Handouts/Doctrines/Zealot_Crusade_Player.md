---
title: "Player Handout \u2014 Zealot Crusade Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.198854+00:00'
world: Both
---


# Zealot Crusade

How it feels
- Hymns, banners, conviction

What changes in travel
- Shrine stops; sermons; choices with gods watching

Crew tips
- Respect rites; keep heads

Risks
- Faith moves people; sometimes overboard

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
