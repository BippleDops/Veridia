---
title: "Player Handout \u2014 S-L-08 Gravity Inversion Storm"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- sky
created: '2025-08-11'
updated: '2025-08-13T01:18:37.208712+00:00'
world: Both
---


# Gravity Inversion Storm

Up and down change places. Your stomach forgets how to fall.

What you notice
- Loose tools float, then thud
- The ship creaks in strange directions

What you can try
- Strap in and call your movements
- Trust the helmsman

Possible outcomes
- You ride it like a story you’ll tell for years
- You come out banged up but smiling
- You hit hard

## Cross-References

- [[Aethermoor_Session_01|06 GM Resources/Session Packets/Aethermoor Session 01]]
