---
title: "Player Handout \u2014 X-003 Anchor Storm"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- mixed
created: '2025-08-11'
updated: '2025-08-13T01:18:37.200831+00:00'
world: Both
---


# Anchor Storm

Anchors sing to one another. The ship steadies; the air tastes like copper and rain.

What you notice
- Hairs lifting on your arms
- A hum in your teeth

What you can try
- Keep the chant
- Watch for trouble in the calm

Possible outcomes
- The way grows still and sure
- The song wavers
- Something tries to break the harmony
