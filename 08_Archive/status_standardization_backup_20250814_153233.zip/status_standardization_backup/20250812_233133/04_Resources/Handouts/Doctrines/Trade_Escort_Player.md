---
title: "Player Handout \u2014 Trade Escort Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.199359+00:00'
world: Both
---


# Trade Escort

How it feels
- Convoys, paperwork, bribes vs. laws

What changes in travel
- More audits; fewer ambushes; schedules matter

Crew tips
- Keep docs clean; talk first

Risks
- Corruption stings; delays attract predators

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
