---
title: "Player Handout \u2014 Memory Warfare Doctrine"
type: handout
status: complete
audience: player
tags:
- both
- complete
- doctrine
- handout
created: '2025-08-11'
updated: '2025-08-13T01:18:37.193444+00:00'
world: Both
---


# Memory Warfare

How it feels
- Deals in whispers; charts as currency; identity at stake

What changes in travel
- Better charts; more tempting offers; bigger risks

Crew tips
- Write down who you are; agree on lines you won’t cross

Risks
- The profit can cost your name

## Cross-References

- [[Doctrine_Quick_Reference|04 Resources/Handouts/Doctrines/Doctrine Quick Reference]]
