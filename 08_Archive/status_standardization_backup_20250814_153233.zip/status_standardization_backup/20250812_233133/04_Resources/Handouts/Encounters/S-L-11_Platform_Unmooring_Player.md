---
title: "Player Handout \u2014 S-L-11 Platform Unmooring"
type: handout
status: complete
audience: player
tags:
- both
- complete
- encounter
- handout
- sky
created: '2025-08-11'
updated: '2025-08-13T01:18:37.205198+00:00'
world: Both
---


# Platform Unmooring

The city shifts underfoot as if remembering how to drift.

What you notice
- Lines along the deck that don’t meet
- A crowd holding its breath

What you can try
- Help crews re-anchor
- Keep people calm

Possible outcomes
- The city holds
- It drifts for a time
- It’s lost
